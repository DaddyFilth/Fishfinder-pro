import type { Spot } from '@/lib/mapFilters';

/**
 * Oklahoma-only map fixtures keep exploration useful during first-run and
 * whenever the optional Supabase database is unavailable. Every spot is inside
 * Oklahoma state bounds; out-of-state fixtures were removed as part of the
 * Oklahoma-only focus.
 */
export const DEFAULT_SPOTS: readonly Spot[] = [
  // Oklahoma City metro
  { id: '00000000-0000-4000-8000-000000000001', name: 'Lake Thunderbird', lat: 35.215, lng: -97.281, water_type: 'freshwater', spot_type: 'lake' },
  { id: '00000000-0000-4000-8000-000000000002', name: 'Lake Hefner', lat: 35.588, lng: -97.588, water_type: 'freshwater', spot_type: 'lake' },
  { id: '00000000-0000-4000-8000-000000000033', name: 'Lake Stanley Draper', lat: 35.333, lng: -97.417, water_type: 'freshwater', spot_type: 'lake' },
  { id: '00000000-0000-4000-8000-000000000034', name: 'Lake Overholser', lat: 35.513, lng: -97.688, water_type: 'freshwater', spot_type: 'lake' },
  { id: '00000000-0000-4000-8000-000000000035', name: 'Arcadia Lake', lat: 35.656, lng: -97.326, water_type: 'freshwater', spot_type: 'lake' },

  // South-central Oklahoma
  { id: '00000000-0000-4000-8000-000000000031', name: 'Purcell Lake', lat: 34.990139, lng: -97.389444, water_type: 'freshwater', spot_type: 'lake' },
  { id: '00000000-0000-4000-8000-000000000032', name: 'Pauls Valley City Lake', lat: 34.782694, lng: -97.204444, water_type: 'freshwater', spot_type: 'lake' },
  { id: '00000000-0000-4000-8000-000000000018', name: 'Lake Murray', lat: 34.083, lng: -97.117, water_type: 'freshwater', spot_type: 'lake' },
  { id: '00000000-0000-4000-8000-000000000019', name: 'Lake of the Arbuckles', lat: 34.438, lng: -96.975, water_type: 'freshwater', spot_type: 'lake' },
  { id: '00000000-0000-4000-8000-000000000020', name: 'McGee Creek Reservoir', lat: 34.354, lng: -95.686, water_type: 'freshwater', spot_type: 'reservoir' },

  // Southeast Oklahoma
  { id: '00000000-0000-4000-8000-000000000003', name: 'Lake Eufaula', lat: 35.304, lng: -95.583, water_type: 'freshwater', spot_type: 'reservoir' },
  { id: '00000000-0000-4000-8000-000000000004', name: 'Lake Texoma', lat: 33.817, lng: -96.610, water_type: 'freshwater', spot_type: 'reservoir' },
  { id: '00000000-0000-4000-8000-000000000006', name: 'Broken Bow Lake', lat: 34.180, lng: -94.752, water_type: 'freshwater', spot_type: 'lake' },
  { id: '00000000-0000-4000-8000-000000000010', name: 'Lake Tenkiller', lat: 35.589, lng: -94.989, water_type: 'freshwater', spot_type: 'lake' },
  { id: '00000000-0000-4000-8000-000000000021', name: 'Sardis Lake', lat: 34.610, lng: -95.410, water_type: 'freshwater', spot_type: 'lake' },
  { id: '00000000-0000-4000-8000-000000000022', name: 'Hugo Lake', lat: 34.030, lng: -95.400, water_type: 'freshwater', spot_type: 'lake' },
  { id: '00000000-0000-4000-8000-000000000023', name: 'Wister Lake', lat: 34.918, lng: -94.717, water_type: 'freshwater', spot_type: 'lake' },
  { id: '00000000-0000-4000-8000-000000000024', name: 'Robert S. Kerr Reservoir', lat: 35.340, lng: -94.940, water_type: 'freshwater', spot_type: 'reservoir' },
  { id: '00000000-0000-4000-8000-000000000025', name: 'Lake Atoka', lat: 34.387, lng: -96.153, water_type: 'freshwater', spot_type: 'lake' },
  { id: '00000000-0000-4000-8000-000000000026', name: 'Lower Mountain Fork River', lat: 34.117, lng: -94.667, water_type: 'freshwater', spot_type: 'river' },
  { id: '00000000-0000-4000-8000-000000000041', name: 'Medicine Creek', lat: 34.736, lng: -98.502, water_type: 'freshwater', spot_type: 'river' },
  { id: '00000000-0000-4000-8000-000000000042', name: 'Blue River Trout Area', lat: 34.230, lng: -96.680, water_type: 'freshwater', spot_type: 'river' },
  { id: '00000000-0000-4000-8000-000000000036', name: 'Illinois River — Tahlequah', lat: 36.168, lng: -94.977, water_type: 'freshwater', spot_type: 'river' },

  // Northeast Oklahoma
  { id: '00000000-0000-4000-8000-000000000005', name: 'Arkansas River — Tulsa', lat: 36.145, lng: -96.006, water_type: 'freshwater', spot_type: 'river' },
  { id: '00000000-0000-4000-8000-000000000011', name: 'Grand Lake o' the Cherokees', lat: 36.588, lng: -94.850, water_type: 'freshwater', spot_type: 'reservoir' },
  { id: '00000000-0000-4000-8000-000000000012', name: 'Keystone Lake', lat: 36.150, lng: -96.270, water_type: 'freshwater', spot_type: 'reservoir' },
  { id: '00000000-0000-4000-8000-000000000013', name: 'Skiatook Lake', lat: 36.358, lng: -96.114, water_type: 'freshwater', spot_type: 'lake' },
  { id: '00000000-0000-4000-8000-000000000014', name: 'Kaw Lake', lat: 36.759, lng: -96.889, water_type: 'freshwater', spot_type: 'reservoir' },
  { id: '00000000-0000-4000-8000-000000000015', name: 'Oologah Lake', lat: 36.448, lng: -95.710, water_type: 'freshwater', spot_type: 'reservoir' },
  { id: '00000000-0000-4000-8000-000000000016', name: 'Fort Gibson Lake', lat: 35.969, lng: -95.220, water_type: 'freshwater', spot_type: 'reservoir' },
  { id: '00000000-0000-4000-8000-000000000017', name: 'Webbers Falls Reservoir', lat: 35.540, lng: -95.220, water_type: 'freshwater', spot_type: 'reservoir' },
  { id: '00000000-0000-4000-8000-000000000027', name: 'Lake Eucha', lat: 36.390, lng: -94.800, water_type: 'freshwater', spot_type: 'lake' },
  { id: '00000000-0000-4000-8000-000000000028', name: 'Spavinaw Lake', lat: 36.400, lng: -95.050, water_type: 'freshwater', spot_type: 'lake' },
  { id: '00000000-0000-4000-8000-000000000029', name: 'Lake Hudson', lat: 36.236, lng: -95.162, water_type: 'freshwater', spot_type: 'lake' },
  { id: '00000000-0000-4000-8000-000000000030', name: 'Copan Lake', lat: 36.630, lng: -95.910, water_type: 'freshwater', spot_type: 'lake' },

  // Western Oklahoma
  { id: '00000000-0000-4000-8000-000000000007', name: 'Red River — Texas County', lat: 33.785, lng: -96.583, water_type: 'freshwater', spot_type: 'river' },
  { id: '00000000-0000-4000-8000-000000000037', name: 'Doc Hollis Lake', lat: 34.397, lng: -99.019, water_type: 'freshwater', spot_type: 'lake' },
  { id: '00000000-0000-4000-8000-000000000008', name: 'Foss Reservoir', lat: 35.545, lng: -99.189, water_type: 'freshwater', spot_type: 'reservoir' },
  { id: '00000000-0000-4000-8000-000000000009', name: 'Altus-Lugert Lake', lat: 34.900, lng: -99.300, water_type: 'freshwater', spot_type: 'reservoir' },
  { id: '00000000-0000-4000-8000-000000000038', name: 'Lake Lawtonka', lat: 34.718, lng: -98.510, water_type: 'freshwater', spot_type: 'lake' },
  { id: '00000000-0000-4000-8000-000000000039', name: 'Waurika Lake', lat: 34.235, lng: -98.180, water_type: 'freshwater', spot_type: 'reservoir' },
  { id: '00000000-0000-4000-8000-000000000040', name: 'Birch Lake', lat: 36.550, lng: -96.320, water_type: 'freshwater', spot_type: 'lake' },
];

export function getDefaultCondition(spot: Spot) {
  const score = spot.spot_type === 'river' ? 74 : spot.spot_type === 'reservoir' ? 68 : 71;
  return {
    spot_id: spot.id,
    air_temp_c: 22,
    water_temp_c: 19,
    water_level_m: spot.spot_type === 'river' ? 1.2 : 2.8,
    flow_rate_cfs: spot.spot_type === 'river' ? 620 : null,
    wind_speed_ms: 3.4,
    wind_dir_deg: 180,
    dissolved_oxygen_mgl: 7.6,
    wave_height_m: null,
    wave_period_s: null,
    swell_direction_deg: null,
    tide_height_m: null,
    tide_type: null,
    pressure_hpa: 1015,
    humidity_pct: 54,
    turbidity_ntu: 3.8,
    ph: 7.4,
    fishing_score: score,
    score_breakdown: { total: score, components: { weather: 78, water: 72, conditions: 69 }, recommendations: ['Local demo conditions are available while live data is offline.'], warnings: [] },
    data_sources: ['Local fallback'],
    cached: false,
    captured_at: new Date().toISOString(),
  };
}
