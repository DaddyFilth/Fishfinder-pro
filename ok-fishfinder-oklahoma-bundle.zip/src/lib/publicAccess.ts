export type VerificationStatus = 'official' | 'community' | 'needs_verification';
export type AccessType =
  | 'shoreline'
  | 'fishing_pier'
  | 'dock'
  | 'boat_ramp'
  | 'parking'
  | 'trailhead';

export type AccessibilityStatus = 'confirmed' | 'not_available' | 'unknown';

export interface PermitRequirement {
  required: boolean;
  kind?:
    | 'state_license'
    | 'city_permit'
    | 'land_access_permit'
    | 'day_use_fee'
    | 'check_in'
    | 'special_regulation';
  summary: string;
  officialUrl?: string;
}

export interface ParkingDetails {
  available: boolean | 'unknown';
  adaStatus: AccessibilityStatus;
  surface?: 'paved' | 'gravel' | 'grass' | 'street' | 'unknown';
  fee?: string;
  notes?: string;
}

export interface PublicFishingAccessPoint {
  id: string;
  spotName: string;
  waterBody: string;
  city: string;
  state: 'OK';
  latitude: number;
  longitude: number;

  publicAccess: boolean;
  accessType: AccessType;
  accessNotes?: string;

  adaFishing: AccessibilityStatus;
  adaParking: AccessibilityStatus;
  pavedRouteToWater: AccessibilityStatus;
  accessibleRestroom: AccessibilityStatus;

  parking: ParkingDetails;

  permit: PermitRequirement;

  operator?: string;
  contact?: string;

  sourceName: string;
  sourceUrl: string;
  verifiedAt: string;
  verificationStatus: VerificationStatus;
}

const ODWCFishingAreas =
  'https://www.wildlifedepartment.com/fishing/regs/department-fishing-areas';

// Oklahoma-only focus: every entry is a publicly accessible fishing location
// in Oklahoma, sourced from the Oklahoma Department of Wildlife Conservation.
export const PUBLIC_FISHING_ACCESS_POINTS: PublicFishingAccessPoint[] = [
  {
    id: 'purcell-lake-public-access',
    spotName: 'Purcell Lake',
    waterBody: 'Purcell City Lake',
    city: 'Purcell',
    state: 'OK',
    latitude: 34.990139,
    longitude: -97.389444,

    publicAccess: true,
    accessType: 'shoreline',
    accessNotes:
      'Public lake location. Verify the nearest open access point, ramp, and parking conditions before travel.',

    adaFishing: 'unknown',
    adaParking: 'unknown',
    pavedRouteToWater: 'unknown',
    accessibleRestroom: 'unknown',

    parking: {
      available: 'unknown',
      adaStatus: 'unknown',
      surface: 'unknown',
      notes: 'Parking details need local verification.',
    },

    permit: {
      required: true,
      kind: 'state_license',
      summary:
        'A valid Oklahoma fishing license is generally required unless an exemption applies. Confirm any city-specific rules before fishing.',
      officialUrl: ODWCFishingAreas,
    },

    operator: 'City of Purcell',
    sourceName: 'Oklahoma Department of Wildlife Conservation',
    sourceUrl:
      'https://www.wildlifedepartment.com/fishing/wheretofish/central/purcell-lake',
    verifiedAt: '2026-09-08',
    verificationStatus: 'official',
  },

  {
    id: 'pauls-valley-city-lake-public-access',
    spotName: 'Pauls Valley City Lake',
    waterBody: 'Pauls Valley City Lake',
    city: 'Pauls Valley',
    state: 'OK',
    latitude: 34.782694,
    longitude: -97.204444,

    publicAccess: true,
    accessType: 'shoreline',
    accessNotes:
      'City lake northeast of Pauls Valley. This record is separate from R.C. Longmire Lake.',

    adaFishing: 'unknown',
    adaParking: 'unknown',
    pavedRouteToWater: 'unknown',
    accessibleRestroom: 'unknown',

    parking: {
      available: 'unknown',
      adaStatus: 'unknown',
      surface: 'unknown',
      notes: 'Confirm the closest public parking and accessible route before traveling.',
    },

    permit: {
      required: true,
      kind: 'state_license',
      summary:
        'A valid Oklahoma fishing license is generally required unless an exemption applies. Confirm City of Pauls Valley requirements before fishing.',
      officialUrl: ODWCFishingAreas,
    },

    operator: 'City of Pauls Valley',
    sourceName: 'Oklahoma Department of Wildlife Conservation',
    sourceUrl:
      'https://www.wildlifedepartment.com/fishing/wheretofish/central/pauls-valley-lake',
    verifiedAt: '2026-09-08',
    verificationStatus: 'official',
  },

  {
    id: 'doc-hollis-ada-parking',
    spotName: 'Doc Hollis Lake',
    waterBody: 'Doc Hollis Lake',
    city: 'Frederick',
    state: 'OK',
    latitude: 34.397,
    longitude: -99.019,

    publicAccess: true,
    accessType: 'parking',
    accessNotes:
      'ODWC documents a fishing dock, entrance road, parking lot, and ADA parking.',

    adaFishing: 'unknown',
    adaParking: 'confirmed',
    pavedRouteToWater: 'unknown',
    accessibleRestroom: 'unknown',

    parking: {
      available: true,
      adaStatus: 'confirmed',
      surface: 'unknown',
      notes:
        'ADA parking is listed by ODWC. Confirm current route and surface conditions before travel.',
    },

    permit: {
      required: true,
      kind: 'state_license',
      summary:
        'A valid Oklahoma fishing license is generally required unless an exemption applies.',
      officialUrl: ODWCFishingAreas,
    },

    operator: 'Oklahoma Department of Wildlife Conservation',
    sourceName: 'ODWC — Doc Hollis Lake',
    sourceUrl:
      'https://www.wildlifedepartment.com/fishing/wheretofish/southwest/doc-hollis',
    verifiedAt: '2026-09-08',
    verificationStatus: 'official',
  },
  {
    id: 'lake-thunderbird-public-access',
    spotName: 'Lake Thunderbird',
    waterBody: 'Lake Thunderbird',
    city: 'Norman',
    state: 'OK',
    latitude: 35.215,
    longitude: -97.281,

    publicAccess: true,
    accessType: 'boat_ramp',
    accessNotes:
      'Public fishing access on Lake Thunderbird. Verify the nearest open access point, ramp, and parking conditions before travel.',

    adaFishing: 'unknown',
    adaParking: 'unknown',
    pavedRouteToWater: 'unknown',
    accessibleRestroom: 'unknown',

    parking: {
      available: 'unknown',
      adaStatus: 'unknown',
      surface: 'unknown',
      notes: 'Parking details need local verification.',
    },

    permit: {
      required: true,
      kind: 'state_license',
      summary:
        'A valid Oklahoma fishing license is generally required unless an exemption applies. Confirm any local rules before fishing.',
      officialUrl: ODWCFishingAreas,
    },

    operator: 'U.S. Army Corps of Engineers / ODWC',
    sourceName: 'Oklahoma Department of Wildlife Conservation',
    sourceUrl: ODWCFishingAreas,
    verifiedAt: '2026-09-08',
    verificationStatus: 'official',
  },
  {
    id: 'lake-hefner-public-access',
    spotName: 'Lake Hefner',
    waterBody: 'Lake Hefner',
    city: 'Oklahoma City',
    state: 'OK',
    latitude: 35.588,
    longitude: -97.588,

    publicAccess: true,
    accessType: 'shoreline',
    accessNotes:
      'Public fishing access on Lake Hefner. Verify the nearest open access point, ramp, and parking conditions before travel.',

    adaFishing: 'unknown',
    adaParking: 'unknown',
    pavedRouteToWater: 'unknown',
    accessibleRestroom: 'unknown',

    parking: {
      available: 'unknown',
      adaStatus: 'unknown',
      surface: 'unknown',
      notes: 'Parking details need local verification.',
    },

    permit: {
      required: true,
      kind: 'state_license',
      summary:
        'A valid Oklahoma fishing license is generally required unless an exemption applies. Confirm any local rules before fishing.',
      officialUrl: ODWCFishingAreas,
    },

    operator: 'City of Oklahoma City',
    sourceName: 'Oklahoma Department of Wildlife Conservation',
    sourceUrl: ODWCFishingAreas,
    verifiedAt: '2026-09-08',
    verificationStatus: 'official',
  },
  {
    id: 'stanley-draper-public-access',
    spotName: 'Lake Stanley Draper',
    waterBody: 'Lake Stanley Draper',
    city: 'Oklahoma City',
    state: 'OK',
    latitude: 35.333,
    longitude: -97.417,

    publicAccess: true,
    accessType: 'boat_ramp',
    accessNotes:
      'Public fishing access on Lake Stanley Draper. Verify the nearest open access point, ramp, and parking conditions before travel.',

    adaFishing: 'unknown',
    adaParking: 'unknown',
    pavedRouteToWater: 'unknown',
    accessibleRestroom: 'unknown',

    parking: {
      available: 'unknown',
      adaStatus: 'unknown',
      surface: 'unknown',
      notes: 'Parking details need local verification.',
    },

    permit: {
      required: true,
      kind: 'state_license',
      summary:
        'A valid Oklahoma fishing license is generally required unless an exemption applies. Confirm any local rules before fishing.',
      officialUrl: ODWCFishingAreas,
    },

    operator: 'City of Oklahoma City',
    sourceName: 'Oklahoma Department of Wildlife Conservation',
    sourceUrl: ODWCFishingAreas,
    verifiedAt: '2026-09-08',
    verificationStatus: 'official',
  },
  {
    id: 'lake-overholser-public-access',
    spotName: 'Lake Overholser',
    waterBody: 'Lake Overholser',
    city: 'Oklahoma City',
    state: 'OK',
    latitude: 35.513,
    longitude: -97.688,

    publicAccess: true,
    accessType: 'shoreline',
    accessNotes:
      'Public fishing access on Lake Overholser. Verify the nearest open access point, ramp, and parking conditions before travel.',

    adaFishing: 'unknown',
    adaParking: 'unknown',
    pavedRouteToWater: 'unknown',
    accessibleRestroom: 'unknown',

    parking: {
      available: 'unknown',
      adaStatus: 'unknown',
      surface: 'unknown',
      notes: 'Parking details need local verification.',
    },

    permit: {
      required: true,
      kind: 'state_license',
      summary:
        'A valid Oklahoma fishing license is generally required unless an exemption applies. Confirm any local rules before fishing.',
      officialUrl: ODWCFishingAreas,
    },

    operator: 'City of Oklahoma City',
    sourceName: 'Oklahoma Department of Wildlife Conservation',
    sourceUrl: ODWCFishingAreas,
    verifiedAt: '2026-09-08',
    verificationStatus: 'official',
  },
  {
    id: 'arcadia-lake-public-access',
    spotName: 'Arcadia Lake',
    waterBody: 'Arcadia Lake',
    city: 'Edmond',
    state: 'OK',
    latitude: 35.656,
    longitude: -97.326,

    publicAccess: true,
    accessType: 'boat_ramp',
    accessNotes:
      'Public fishing access on Arcadia Lake. Verify the nearest open access point, ramp, and parking conditions before travel.',

    adaFishing: 'unknown',
    adaParking: 'unknown',
    pavedRouteToWater: 'unknown',
    accessibleRestroom: 'unknown',

    parking: {
      available: 'unknown',
      adaStatus: 'unknown',
      surface: 'unknown',
      notes: 'Parking details need local verification.',
    },

    permit: {
      required: true,
      kind: 'state_license',
      summary:
        'A valid Oklahoma fishing license is generally required unless an exemption applies. Confirm any local rules before fishing.',
      officialUrl: ODWCFishingAreas,
    },

    operator: 'U.S. Army Corps of Engineers',
    sourceName: 'Oklahoma Department of Wildlife Conservation',
    sourceUrl: ODWCFishingAreas,
    verifiedAt: '2026-09-08',
    verificationStatus: 'official',
  },
  {
    id: 'lake-eufaula-public-access',
    spotName: 'Lake Eufaula',
    waterBody: 'Lake Eufaula',
    city: 'Eufaula',
    state: 'OK',
    latitude: 35.304,
    longitude: -95.583,

    publicAccess: true,
    accessType: 'boat_ramp',
    accessNotes:
      'Public fishing access on Lake Eufaula. Verify the nearest open access point, ramp, and parking conditions before travel.',

    adaFishing: 'unknown',
    adaParking: 'unknown',
    pavedRouteToWater: 'unknown',
    accessibleRestroom: 'unknown',

    parking: {
      available: 'unknown',
      adaStatus: 'unknown',
      surface: 'unknown',
      notes: 'Parking details need local verification.',
    },

    permit: {
      required: true,
      kind: 'state_license',
      summary:
        'A valid Oklahoma fishing license is generally required unless an exemption applies. Confirm any local rules before fishing.',
      officialUrl: ODWCFishingAreas,
    },

    operator: 'U.S. Army Corps of Engineers',
    sourceName: 'Oklahoma Department of Wildlife Conservation',
    sourceUrl: ODWCFishingAreas,
    verifiedAt: '2026-09-08',
    verificationStatus: 'official',
  },
  {
    id: 'lake-texoma-public-access',
    spotName: 'Lake Texoma',
    waterBody: 'Lake Texoma',
    city: 'Kingston',
    state: 'OK',
    latitude: 33.817,
    longitude: -96.61,

    publicAccess: true,
    accessType: 'boat_ramp',
    accessNotes:
      'Public fishing access on Lake Texoma. Verify the nearest open access point, ramp, and parking conditions before travel.',

    adaFishing: 'unknown',
    adaParking: 'unknown',
    pavedRouteToWater: 'unknown',
    accessibleRestroom: 'unknown',

    parking: {
      available: 'unknown',
      adaStatus: 'unknown',
      surface: 'unknown',
      notes: 'Parking details need local verification.',
    },

    permit: {
      required: true,
      kind: 'state_license',
      summary:
        'A valid Oklahoma fishing license is generally required unless an exemption applies. Confirm any local rules before fishing.',
      officialUrl: ODWCFishingAreas,
    },

    operator: 'U.S. Army Corps of Engineers',
    sourceName: 'Oklahoma Department of Wildlife Conservation',
    sourceUrl: ODWCFishingAreas,
    verifiedAt: '2026-09-08',
    verificationStatus: 'official',
  },
  {
    id: 'broken-bow-lake-public-access',
    spotName: 'Broken Bow Lake',
    waterBody: 'Broken Bow Lake',
    city: 'Broken Bow',
    state: 'OK',
    latitude: 34.18,
    longitude: -94.752,

    publicAccess: true,
    accessType: 'shoreline',
    accessNotes:
      'Public fishing access on Broken Bow Lake. Verify the nearest open access point, ramp, and parking conditions before travel.',

    adaFishing: 'unknown',
    adaParking: 'unknown',
    pavedRouteToWater: 'unknown',
    accessibleRestroom: 'unknown',

    parking: {
      available: 'unknown',
      adaStatus: 'unknown',
      surface: 'unknown',
      notes: 'Parking details need local verification.',
    },

    permit: {
      required: true,
      kind: 'state_license',
      summary:
        'A valid Oklahoma fishing license is generally required unless an exemption applies. Confirm any local rules before fishing.',
      officialUrl: ODWCFishingAreas,
    },

    operator: 'U.S. Army Corps of Engineers',
    sourceName: 'Oklahoma Department of Wildlife Conservation',
    sourceUrl: ODWCFishingAreas,
    verifiedAt: '2026-09-08',
    verificationStatus: 'official',
  },
  {
    id: 'tenkiller-lake-public-access',
    spotName: 'Lake Tenkiller',
    waterBody: 'Lake Tenkiller',
    city: 'Cookson',
    state: 'OK',
    latitude: 35.589,
    longitude: -94.989,

    publicAccess: true,
    accessType: 'boat_ramp',
    accessNotes:
      'Public fishing access on Lake Tenkiller. Verify the nearest open access point, ramp, and parking conditions before travel.',

    adaFishing: 'unknown',
    adaParking: 'unknown',
    pavedRouteToWater: 'unknown',
    accessibleRestroom: 'unknown',

    parking: {
      available: 'unknown',
      adaStatus: 'unknown',
      surface: 'unknown',
      notes: 'Parking details need local verification.',
    },

    permit: {
      required: true,
      kind: 'state_license',
      summary:
        'A valid Oklahoma fishing license is generally required unless an exemption applies. Confirm any local rules before fishing.',
      officialUrl: ODWCFishingAreas,
    },

    operator: 'U.S. Army Corps of Engineers',
    sourceName: 'Oklahoma Department of Wildlife Conservation',
    sourceUrl: ODWCFishingAreas,
    verifiedAt: '2026-09-08',
    verificationStatus: 'official',
  },
  {
    id: 'grand-lake-public-access',
    spotName: 'Grand Lake o' the Cherokees',
    waterBody: 'Grand Lake o' the Cherokees',
    city: 'Grove',
    state: 'OK',
    latitude: 36.588,
    longitude: -94.85,

    publicAccess: true,
    accessType: 'boat_ramp',
    accessNotes:
      'Public fishing access on Grand Lake o' the Cherokees. Verify the nearest open access point, ramp, and parking conditions before travel.',

    adaFishing: 'unknown',
    adaParking: 'unknown',
    pavedRouteToWater: 'unknown',
    accessibleRestroom: 'unknown',

    parking: {
      available: 'unknown',
      adaStatus: 'unknown',
      surface: 'unknown',
      notes: 'Parking details need local verification.',
    },

    permit: {
      required: true,
      kind: 'state_license',
      summary:
        'A valid Oklahoma fishing license is generally required unless an exemption applies. Confirm any local rules before fishing.',
      officialUrl: ODWCFishingAreas,
    },

    operator: 'Grand River Dam Authority',
    sourceName: 'Oklahoma Department of Wildlife Conservation',
    sourceUrl: ODWCFishingAreas,
    verifiedAt: '2026-09-08',
    verificationStatus: 'official',
  },
  {
    id: 'keystone-lake-public-access',
    spotName: 'Keystone Lake',
    waterBody: 'Keystone Lake',
    city: 'Sand Springs',
    state: 'OK',
    latitude: 36.15,
    longitude: -96.27,

    publicAccess: true,
    accessType: 'boat_ramp',
    accessNotes:
      'Public fishing access on Keystone Lake. Verify the nearest open access point, ramp, and parking conditions before travel.',

    adaFishing: 'unknown',
    adaParking: 'unknown',
    pavedRouteToWater: 'unknown',
    accessibleRestroom: 'unknown',

    parking: {
      available: 'unknown',
      adaStatus: 'unknown',
      surface: 'unknown',
      notes: 'Parking details need local verification.',
    },

    permit: {
      required: true,
      kind: 'state_license',
      summary:
        'A valid Oklahoma fishing license is generally required unless an exemption applies. Confirm any local rules before fishing.',
      officialUrl: ODWCFishingAreas,
    },

    operator: 'U.S. Army Corps of Engineers',
    sourceName: 'Oklahoma Department of Wildlife Conservation',
    sourceUrl: ODWCFishingAreas,
    verifiedAt: '2026-09-08',
    verificationStatus: 'official',
  },
  {
    id: 'skiatook-lake-public-access',
    spotName: 'Skiatook Lake',
    waterBody: 'Skiatook Lake',
    city: 'Skiatook',
    state: 'OK',
    latitude: 36.358,
    longitude: -96.114,

    publicAccess: true,
    accessType: 'boat_ramp',
    accessNotes:
      'Public fishing access on Skiatook Lake. Verify the nearest open access point, ramp, and parking conditions before travel.',

    adaFishing: 'unknown',
    adaParking: 'unknown',
    pavedRouteToWater: 'unknown',
    accessibleRestroom: 'unknown',

    parking: {
      available: 'unknown',
      adaStatus: 'unknown',
      surface: 'unknown',
      notes: 'Parking details need local verification.',
    },

    permit: {
      required: true,
      kind: 'state_license',
      summary:
        'A valid Oklahoma fishing license is generally required unless an exemption applies. Confirm any local rules before fishing.',
      officialUrl: ODWCFishingAreas,
    },

    operator: 'U.S. Army Corps of Engineers',
    sourceName: 'Oklahoma Department of Wildlife Conservation',
    sourceUrl: ODWCFishingAreas,
    verifiedAt: '2026-09-08',
    verificationStatus: 'official',
  },
  {
    id: 'kaw-lake-public-access',
    spotName: 'Kaw Lake',
    waterBody: 'Kaw Lake',
    city: 'Ponca City',
    state: 'OK',
    latitude: 36.759,
    longitude: -96.889,

    publicAccess: true,
    accessType: 'boat_ramp',
    accessNotes:
      'Public fishing access on Kaw Lake. Verify the nearest open access point, ramp, and parking conditions before travel.',

    adaFishing: 'unknown',
    adaParking: 'unknown',
    pavedRouteToWater: 'unknown',
    accessibleRestroom: 'unknown',

    parking: {
      available: 'unknown',
      adaStatus: 'unknown',
      surface: 'unknown',
      notes: 'Parking details need local verification.',
    },

    permit: {
      required: true,
      kind: 'state_license',
      summary:
        'A valid Oklahoma fishing license is generally required unless an exemption applies. Confirm any local rules before fishing.',
      officialUrl: ODWCFishingAreas,
    },

    operator: 'U.S. Army Corps of Engineers',
    sourceName: 'Oklahoma Department of Wildlife Conservation',
    sourceUrl: ODWCFishingAreas,
    verifiedAt: '2026-09-08',
    verificationStatus: 'official',
  },
  {
    id: 'oologah-lake-public-access',
    spotName: 'Oologah Lake',
    waterBody: 'Oologah Lake',
    city: 'Oologah',
    state: 'OK',
    latitude: 36.448,
    longitude: -95.71,

    publicAccess: true,
    accessType: 'boat_ramp',
    accessNotes:
      'Public fishing access on Oologah Lake. Verify the nearest open access point, ramp, and parking conditions before travel.',

    adaFishing: 'unknown',
    adaParking: 'unknown',
    pavedRouteToWater: 'unknown',
    accessibleRestroom: 'unknown',

    parking: {
      available: 'unknown',
      adaStatus: 'unknown',
      surface: 'unknown',
      notes: 'Parking details need local verification.',
    },

    permit: {
      required: true,
      kind: 'state_license',
      summary:
        'A valid Oklahoma fishing license is generally required unless an exemption applies. Confirm any local rules before fishing.',
      officialUrl: ODWCFishingAreas,
    },

    operator: 'U.S. Army Corps of Engineers',
    sourceName: 'Oklahoma Department of Wildlife Conservation',
    sourceUrl: ODWCFishingAreas,
    verifiedAt: '2026-09-08',
    verificationStatus: 'official',
  },
  {
    id: 'fort-gibson-lake-public-access',
    spotName: 'Fort Gibson Lake',
    waterBody: 'Fort Gibson Lake',
    city: 'Fort Gibson',
    state: 'OK',
    latitude: 35.969,
    longitude: -95.22,

    publicAccess: true,
    accessType: 'boat_ramp',
    accessNotes:
      'Public fishing access on Fort Gibson Lake. Verify the nearest open access point, ramp, and parking conditions before travel.',

    adaFishing: 'unknown',
    adaParking: 'unknown',
    pavedRouteToWater: 'unknown',
    accessibleRestroom: 'unknown',

    parking: {
      available: 'unknown',
      adaStatus: 'unknown',
      surface: 'unknown',
      notes: 'Parking details need local verification.',
    },

    permit: {
      required: true,
      kind: 'state_license',
      summary:
        'A valid Oklahoma fishing license is generally required unless an exemption applies. Confirm any local rules before fishing.',
      officialUrl: ODWCFishingAreas,
    },

    operator: 'U.S. Army Corps of Engineers',
    sourceName: 'Oklahoma Department of Wildlife Conservation',
    sourceUrl: ODWCFishingAreas,
    verifiedAt: '2026-09-08',
    verificationStatus: 'official',
  },
  {
    id: 'lake-murray-public-access',
    spotName: 'Lake Murray',
    waterBody: 'Lake Murray',
    city: 'Ardmore',
    state: 'OK',
    latitude: 34.083,
    longitude: -97.117,

    publicAccess: true,
    accessType: 'shoreline',
    accessNotes:
      'Public fishing access on Lake Murray. Verify the nearest open access point, ramp, and parking conditions before travel.',

    adaFishing: 'unknown',
    adaParking: 'unknown',
    pavedRouteToWater: 'unknown',
    accessibleRestroom: 'unknown',

    parking: {
      available: 'unknown',
      adaStatus: 'unknown',
      surface: 'unknown',
      notes: 'Parking details need local verification.',
    },

    permit: {
      required: true,
      kind: 'state_license',
      summary:
        'A valid Oklahoma fishing license is generally required unless an exemption applies. Confirm any local rules before fishing.',
      officialUrl: ODWCFishingAreas,
    },

    operator: 'Oklahoma Department of Wildlife Conservation',
    sourceName: 'Oklahoma Department of Wildlife Conservation',
    sourceUrl: ODWCFishingAreas,
    verifiedAt: '2026-09-08',
    verificationStatus: 'official',
  },
  {
    id: 'lake-arbuckles-public-access',
    spotName: 'Lake of the Arbuckles',
    waterBody: 'Lake of the Arbuckles',
    city: 'Sulphur',
    state: 'OK',
    latitude: 34.438,
    longitude: -96.975,

    publicAccess: true,
    accessType: 'shoreline',
    accessNotes:
      'Public fishing access on Lake of the Arbuckles. Verify the nearest open access point, ramp, and parking conditions before travel.',

    adaFishing: 'unknown',
    adaParking: 'unknown',
    pavedRouteToWater: 'unknown',
    accessibleRestroom: 'unknown',

    parking: {
      available: 'unknown',
      adaStatus: 'unknown',
      surface: 'unknown',
      notes: 'Parking details need local verification.',
    },

    permit: {
      required: true,
      kind: 'state_license',
      summary:
        'A valid Oklahoma fishing license is generally required unless an exemption applies. Confirm any local rules before fishing.',
      officialUrl: ODWCFishingAreas,
    },

    operator: 'National Park Service / ODWC',
    sourceName: 'Oklahoma Department of Wildlife Conservation',
    sourceUrl: ODWCFishingAreas,
    verifiedAt: '2026-09-08',
    verificationStatus: 'official',
  },
  {
    id: 'mcgee-creek-public-access',
    spotName: 'McGee Creek Reservoir',
    waterBody: 'McGee Creek Reservoir',
    city: 'Atoka',
    state: 'OK',
    latitude: 34.354,
    longitude: -95.686,

    publicAccess: true,
    accessType: 'shoreline',
    accessNotes:
      'Public fishing access on McGee Creek Reservoir. Verify the nearest open access point, ramp, and parking conditions before travel.',

    adaFishing: 'unknown',
    adaParking: 'unknown',
    pavedRouteToWater: 'unknown',
    accessibleRestroom: 'unknown',

    parking: {
      available: 'unknown',
      adaStatus: 'unknown',
      surface: 'unknown',
      notes: 'Parking details need local verification.',
    },

    permit: {
      required: true,
      kind: 'state_license',
      summary:
        'A valid Oklahoma fishing license is generally required unless an exemption applies. Confirm any local rules before fishing.',
      officialUrl: ODWCFishingAreas,
    },

    operator: 'McGee Creek Authority / ODWC',
    sourceName: 'Oklahoma Department of Wildlife Conservation',
    sourceUrl: ODWCFishingAreas,
    verifiedAt: '2026-09-08',
    verificationStatus: 'official',
  },
  {
    id: 'sardis-lake-public-access',
    spotName: 'Sardis Lake',
    waterBody: 'Sardis Lake',
    city: 'Clayton',
    state: 'OK',
    latitude: 34.61,
    longitude: -95.41,

    publicAccess: true,
    accessType: 'shoreline',
    accessNotes:
      'Public fishing access on Sardis Lake. Verify the nearest open access point, ramp, and parking conditions before travel.',

    adaFishing: 'unknown',
    adaParking: 'unknown',
    pavedRouteToWater: 'unknown',
    accessibleRestroom: 'unknown',

    parking: {
      available: 'unknown',
      adaStatus: 'unknown',
      surface: 'unknown',
      notes: 'Parking details need local verification.',
    },

    permit: {
      required: true,
      kind: 'state_license',
      summary:
        'A valid Oklahoma fishing license is generally required unless an exemption applies. Confirm any local rules before fishing.',
      officialUrl: ODWCFishingAreas,
    },

    operator: 'U.S. Army Corps of Engineers',
    sourceName: 'Oklahoma Department of Wildlife Conservation',
    sourceUrl: ODWCFishingAreas,
    verifiedAt: '2026-09-08',
    verificationStatus: 'official',
  },
  {
    id: 'hugo-lake-public-access',
    spotName: 'Hugo Lake',
    waterBody: 'Hugo Lake',
    city: 'Hugo',
    state: 'OK',
    latitude: 34.03,
    longitude: -95.4,

    publicAccess: true,
    accessType: 'boat_ramp',
    accessNotes:
      'Public fishing access on Hugo Lake. Verify the nearest open access point, ramp, and parking conditions before travel.',

    adaFishing: 'unknown',
    adaParking: 'unknown',
    pavedRouteToWater: 'unknown',
    accessibleRestroom: 'unknown',

    parking: {
      available: 'unknown',
      adaStatus: 'unknown',
      surface: 'unknown',
      notes: 'Parking details need local verification.',
    },

    permit: {
      required: true,
      kind: 'state_license',
      summary:
        'A valid Oklahoma fishing license is generally required unless an exemption applies. Confirm any local rules before fishing.',
      officialUrl: ODWCFishingAreas,
    },

    operator: 'U.S. Army Corps of Engineers',
    sourceName: 'Oklahoma Department of Wildlife Conservation',
    sourceUrl: ODWCFishingAreas,
    verifiedAt: '2026-09-08',
    verificationStatus: 'official',
  },
  {
    id: 'wister-lake-public-access',
    spotName: 'Wister Lake',
    waterBody: 'Wister Lake',
    city: 'Wister',
    state: 'OK',
    latitude: 34.918,
    longitude: -94.717,

    publicAccess: true,
    accessType: 'shoreline',
    accessNotes:
      'Public fishing access on Wister Lake. Verify the nearest open access point, ramp, and parking conditions before travel.',

    adaFishing: 'unknown',
    adaParking: 'unknown',
    pavedRouteToWater: 'unknown',
    accessibleRestroom: 'unknown',

    parking: {
      available: 'unknown',
      adaStatus: 'unknown',
      surface: 'unknown',
      notes: 'Parking details need local verification.',
    },

    permit: {
      required: true,
      kind: 'state_license',
      summary:
        'A valid Oklahoma fishing license is generally required unless an exemption applies. Confirm any local rules before fishing.',
      officialUrl: ODWCFishingAreas,
    },

    operator: 'U.S. Army Corps of Engineers',
    sourceName: 'Oklahoma Department of Wildlife Conservation',
    sourceUrl: ODWCFishingAreas,
    verifiedAt: '2026-09-08',
    verificationStatus: 'official',
  },
  {
    id: 'waurika-lake-public-access',
    spotName: 'Waurika Lake',
    waterBody: 'Waurika Lake',
    city: 'Waurika',
    state: 'OK',
    latitude: 34.235,
    longitude: -98.18,

    publicAccess: true,
    accessType: 'shoreline',
    accessNotes:
      'Public fishing access on Waurika Lake. Verify the nearest open access point, ramp, and parking conditions before travel.',

    adaFishing: 'unknown',
    adaParking: 'unknown',
    pavedRouteToWater: 'unknown',
    accessibleRestroom: 'unknown',

    parking: {
      available: 'unknown',
      adaStatus: 'unknown',
      surface: 'unknown',
      notes: 'Parking details need local verification.',
    },

    permit: {
      required: true,
      kind: 'state_license',
      summary:
        'A valid Oklahoma fishing license is generally required unless an exemption applies. Confirm any local rules before fishing.',
      officialUrl: ODWCFishingAreas,
    },

    operator: 'U.S. Army Corps of Engineers',
    sourceName: 'Oklahoma Department of Wildlife Conservation',
    sourceUrl: ODWCFishingAreas,
    verifiedAt: '2026-09-08',
    verificationStatus: 'official',
  },
  {
    id: 'foss-lake-public-access',
    spotName: 'Foss Reservoir',
    waterBody: 'Foss Reservoir',
    city: 'Foss',
    state: 'OK',
    latitude: 35.545,
    longitude: -99.189,

    publicAccess: true,
    accessType: 'boat_ramp',
    accessNotes:
      'Public fishing access on Foss Reservoir. Verify the nearest open access point, ramp, and parking conditions before travel.',

    adaFishing: 'unknown',
    adaParking: 'unknown',
    pavedRouteToWater: 'unknown',
    accessibleRestroom: 'unknown',

    parking: {
      available: 'unknown',
      adaStatus: 'unknown',
      surface: 'unknown',
      notes: 'Parking details need local verification.',
    },

    permit: {
      required: true,
      kind: 'state_license',
      summary:
        'A valid Oklahoma fishing license is generally required unless an exemption applies. Confirm any local rules before fishing.',
      officialUrl: ODWCFishingAreas,
    },

    operator: 'Bureau of Reclamation / ODWC',
    sourceName: 'Oklahoma Department of Wildlife Conservation',
    sourceUrl: ODWCFishingAreas,
    verifiedAt: '2026-09-08',
    verificationStatus: 'official',
  },
  {
    id: 'altus-lugert-public-access',
    spotName: 'Altus-Lugert Lake',
    waterBody: 'Altus-Lugert Lake',
    city: 'Lugert',
    state: 'OK',
    latitude: 34.9,
    longitude: -99.3,

    publicAccess: true,
    accessType: 'shoreline',
    accessNotes:
      'Public fishing access on Altus-Lugert Lake. Verify the nearest open access point, ramp, and parking conditions before travel.',

    adaFishing: 'unknown',
    adaParking: 'unknown',
    pavedRouteToWater: 'unknown',
    accessibleRestroom: 'unknown',

    parking: {
      available: 'unknown',
      adaStatus: 'unknown',
      surface: 'unknown',
      notes: 'Parking details need local verification.',
    },

    permit: {
      required: true,
      kind: 'state_license',
      summary:
        'A valid Oklahoma fishing license is generally required unless an exemption applies. Confirm any local rules before fishing.',
      officialUrl: ODWCFishingAreas,
    },

    operator: 'Oklahoma Water Resources Board',
    sourceName: 'Oklahoma Department of Wildlife Conservation',
    sourceUrl: ODWCFishingAreas,
    verifiedAt: '2026-09-08',
    verificationStatus: 'official',
  },
  {
    id: 'lake-lawtonka-public-access',
    spotName: 'Lake Lawtonka',
    waterBody: 'Lake Lawtonka',
    city: 'Lawton',
    state: 'OK',
    latitude: 34.718,
    longitude: -98.51,

    publicAccess: true,
    accessType: 'shoreline',
    accessNotes:
      'Public fishing access on Lake Lawtonka. Verify the nearest open access point, ramp, and parking conditions before travel.',

    adaFishing: 'unknown',
    adaParking: 'unknown',
    pavedRouteToWater: 'unknown',
    accessibleRestroom: 'unknown',

    parking: {
      available: 'unknown',
      adaStatus: 'unknown',
      surface: 'unknown',
      notes: 'Parking details need local verification.',
    },

    permit: {
      required: true,
      kind: 'state_license',
      summary:
        'A valid Oklahoma fishing license is generally required unless an exemption applies. Confirm any local rules before fishing.',
      officialUrl: ODWCFishingAreas,
    },

    operator: 'City of Lawton',
    sourceName: 'Oklahoma Department of Wildlife Conservation',
    sourceUrl: ODWCFishingAreas,
    verifiedAt: '2026-09-08',
    verificationStatus: 'official',
  },
  {
    id: 'medicine-creek-trout-area',
    spotName: 'Medicine Creek Trout Area',
    waterBody: 'Medicine Creek',
    city: 'Medicine Park',
    state: 'OK',
    latitude: 34.736,
    longitude: -98.502,

    publicAccess: true,
    accessType: 'shoreline',
    accessNotes:
      'ODWC-designated trout area from Gondola Lake dam downstream to the State Highway 49 bridge. A sidewalk along the east side of the creek offers the best bank access; parking and fishing access are found along the east bank just north of the SH 49 bridge. The west side is accessible on foot — avoid trespassing on residential property. Rainbow trout stocked Nov 1 – Mar 15.',

    adaFishing: 'unknown',
    adaParking: 'unknown',
    pavedRouteToWater: 'unknown',
    accessibleRestroom: 'unknown',

    parking: {
      available: true,
      adaStatus: 'unknown',
      surface: 'unknown',
      notes: 'Parking along the east bank just north of the State Highway 49 bridge.',
    },

    permit: {
      required: true,
      kind: 'state_license',
      summary:
        'A valid Oklahoma fishing license is required. Trout season regulations apply (Nov 1 – Mar 15): one rod and reel per person and a daily trout limit per current ODWC trout regulations.',
      officialUrl: 'https://www.wildlifedepartment.com/fishing/resources/trout-information',
    },

    operator: 'City of Medicine Park',
    sourceName: 'ODWC — Medicine Creek Trout Area',
    sourceUrl:
      'https://www.wildlifedepartment.com/fishing/wheretofish/southwest/medicine-creek-trout-area',
    verifiedAt: '2026-09-09',
    verificationStatus: 'official',
  },
  {
    id: 'blue-river-public-access',
    spotName: 'Blue River',
    waterBody: 'Blue River',
    city: 'Tishomingo',
    state: 'OK',
    latitude: 34.23,
    longitude: -96.68,

    publicAccess: true,
    accessType: 'shoreline',
    accessNotes:
      'Public fishing access on Blue River. Verify the nearest open access point, ramp, and parking conditions before travel.',

    adaFishing: 'unknown',
    adaParking: 'unknown',
    pavedRouteToWater: 'unknown',
    accessibleRestroom: 'unknown',

    parking: {
      available: 'unknown',
      adaStatus: 'unknown',
      surface: 'unknown',
      notes: 'Parking details need local verification.',
    },

    permit: {
      required: true,
      kind: 'state_license',
      summary:
        'A valid Oklahoma fishing license is generally required unless an exemption applies. Confirm any local rules before fishing.',
      officialUrl: ODWCFishingAreas,
    },

    operator: 'Oklahoma Department of Wildlife Conservation',
    sourceName: 'Oklahoma Department of Wildlife Conservation',
    sourceUrl: ODWCFishingAreas,
    verifiedAt: '2026-09-08',
    verificationStatus: 'official',
  },
  {
    id: 'illinois-river-public-access',
    spotName: 'Illinois River',
    waterBody: 'Illinois River',
    city: 'Tahlequah',
    state: 'OK',
    latitude: 35.83,
    longitude: -94.97,

    publicAccess: true,
    accessType: 'shoreline',
    accessNotes:
      'Public fishing access on Illinois River. Verify the nearest open access point, ramp, and parking conditions before travel.',

    adaFishing: 'unknown',
    adaParking: 'unknown',
    pavedRouteToWater: 'unknown',
    accessibleRestroom: 'unknown',

    parking: {
      available: 'unknown',
      adaStatus: 'unknown',
      surface: 'unknown',
      notes: 'Parking details need local verification.',
    },

    permit: {
      required: true,
      kind: 'state_license',
      summary:
        'A valid Oklahoma fishing license is generally required unless an exemption applies. Confirm any local rules before fishing.',
      officialUrl: ODWCFishingAreas,
    },

    operator: 'Oklahoma Department of Wildlife Conservation',
    sourceName: 'Oklahoma Department of Wildlife Conservation',
    sourceUrl: ODWCFishingAreas,
    verifiedAt: '2026-09-08',
    verificationStatus: 'official',
  },
];

export interface PublicAccessFilters {
  publicFishing: boolean;
  adaFishing: boolean;
  adaParking: boolean;
  boatRamp: boolean;
  shoreline: boolean;
  parking: boolean;
  permitRequired: boolean;
}

export const DEFAULT_PUBLIC_ACCESS_FILTERS: PublicAccessFilters = {
  publicFishing: false,
  adaFishing: false,
  adaParking: false,
  boatRamp: false,
  shoreline: false,
  parking: false,
  permitRequired: false,
};

export function filterPublicAccessPoints(
  points: PublicFishingAccessPoint[],
  filters: PublicAccessFilters,
): PublicFishingAccessPoint[] {
  return points.filter((point) => {
    if (filters.publicFishing && !point.publicAccess) return false;
    if (filters.adaFishing && point.adaFishing !== 'confirmed') return false;
    if (filters.adaParking && point.adaParking !== 'confirmed') return false;
    if (filters.boatRamp && point.accessType !== 'boat_ramp') return false;
    if (filters.shoreline && point.accessType !== 'shoreline') return false;
    if (filters.parking && point.parking.available !== true) return false;
    if (filters.permitRequired && !point.permit.required) return false;
    return true;
  });
}

export function validatePublicAccessData(
  points: PublicFishingAccessPoint[] = PUBLIC_FISHING_ACCESS_POINTS,
): string[] {
  const errors: string[] = [];
  const ids = new Set<string>();

  for (const point of points) {
    if (ids.has(point.id)) errors.push(`Duplicate public access ID: ${point.id}`);
    ids.add(point.id);

    if (!point.spotName.trim()) errors.push(`${point.id}: missing spotName`);
    if (!point.sourceUrl.startsWith('https://')) {
      errors.push(`${point.id}: sourceUrl must use https`);
    }
    if (!/^\d{4}-\d{2}-\d{2}$/.test(point.verifiedAt)) {
      errors.push(`${point.id}: verifiedAt must be YYYY-MM-DD`);
    }
    if (point.latitude < 33.5 || point.latitude > 37.2) {
      errors.push(`${point.id}: latitude is outside Oklahoma bounds`);
    }
    if (point.longitude < -103.2 || point.longitude > -94.3) {
      errors.push(`${point.id}: longitude is outside Oklahoma bounds`);
    }
    if (point.adaFishing === 'confirmed' && point.verificationStatus !== 'official') {
      errors.push(`${point.id}: confirmed ADA fishing must have an official source`);
    }
    if (point.adaParking === 'confirmed' && point.verificationStatus !== 'official') {
      errors.push(`${point.id}: confirmed ADA parking must have an official source`);
    }
  }

  return errors;
}
