export type SpeciesHabitat = 'Freshwater' | 'Saltwater' | 'Anadromous';
export type SpeciesDifficulty = 'Easy' | 'Medium' | 'Hard';

export interface SpeciesAdviceConfig {
  optTempMin: number;
  optTempMax: number;
  baitsWarm: readonly string[];
  baitsCold: readonly string[];
  techniqueWarm: string;
  techniqueCold: string;
  depthWarm: string;
  depthCold: string;
}

export interface Species {
  id: string;
  name: string;
  aliases: readonly string[];
  scientificName: string;
  habitat: SpeciesHabitat;
  group: SpeciesGroup;
  states: readonly NorthAmericanState[];
  difficulty: SpeciesDifficulty;
  record: string;
  image: string;
  imageAlt: string;
  season: readonly string[];
  bestBait: readonly string[];
  bestTime: string;
  depth: string;
  habitatNotes: string;
  tips: string;
  activity: readonly number[];
  advice: SpeciesAdviceConfig;
}

export type NorthAmericanState =
  | 'AL' | 'AK' | 'AZ' | 'AR' | 'CA' | 'CO' | 'CT' | 'DE' | 'FL' | 'GA'
  | 'HI' | 'ID' | 'IL' | 'IN' | 'IA' | 'KS' | 'KY' | 'LA' | 'ME' | 'MD'
  | 'MA' | 'MI' | 'MN' | 'MS' | 'MO' | 'MT' | 'NE' | 'NV' | 'NH' | 'NJ'
  | 'NM' | 'NY' | 'NC' | 'ND' | 'OH' | 'OK' | 'OR' | 'PA' | 'RI' | 'SC'
  | 'SD' | 'TN' | 'TX' | 'UT' | 'VT' | 'VA' | 'WA' | 'WV' | 'WI' | 'WY';

export type SpeciesStateFilter = 'All' | NorthAmericanState;

// Oklahoma-only focus: the app covers only species that can be encountered in
// Oklahoma waters, so the state filter list is limited to Oklahoma.
export const STATE_FILTERS: readonly { code: NorthAmericanState; name: string }[] = [
  { code: 'OK', name: 'Oklahoma' },
];

export type SpeciesFilter = 'All' | SpeciesHabitat;
export type SpeciesGroup = 'Bass' | 'Panfish' | 'Trout' | 'Catfish' | 'Pike' | 'Walleye' | 'Inshore' | 'Anadromous';
export type SpeciesGroupFilter = 'All' | SpeciesGroup;

export const SPECIES_FILTERS: readonly SpeciesFilter[] = [
  'All',
  'Freshwater',
];

export const SPECIES_GROUP_FILTERS: readonly SpeciesGroupFilter[] = [
  'All',
  'Bass',
  'Panfish',
  'Trout',
  'Catfish',
  'Pike',
  'Walleye',
];

// Oklahoma-only species catalog: every entry below can be encountered in
// Oklahoma waters, whether native or introduced (e.g. ODWC-stocked trout).
// Saltwater and anadromous species were removed — Oklahoma has no saltwater.
export const SPECIES: readonly Species[] = [
  {
    id: 'largemouth-bass',
    name: 'Largemouth Bass',
    aliases: [],
    scientificName: 'Micropterus salmoides',
    habitat: 'Freshwater',
    group: 'Bass',
    states: ['AL', 'AR', 'AZ', 'CA', 'CO', 'FL', 'GA', 'IA', 'IL', 'IN', 'KS', 'KY', 'LA', 'MD', 'MO', 'MS', 'NC', 'NE', 'NM', 'NY', 'OH', 'OK', 'PA', 'SC', 'TN', 'TX', 'VA', 'WI', 'WV'],
    difficulty: 'Medium',
    record: '22 lb 4 oz',
    image: '/fish/largemouth-bass.jpg',
    imageAlt: 'Largemouth bass swimming in a clear freshwater lake.',
    season: ['Spring', 'Summer', 'Fall'],
    bestBait: ['Plastic worms', 'Crankbaits', 'Spinnerbaits', 'Frogs'],
    bestTime: 'Dawn & dusk',
    depth: '2–15 ft',
    habitatNotes: 'Weeds, structure, and docks',
    tips: 'Target shade and vegetation in warm water; work topwater around cover during low light.',
    activity: [4, 5, 9, 8, 7, 6, 5, 6, 7, 8, 5, 3],
    advice: {
      optTempMin: 15.6, optTempMax: 26.7,
      baitsWarm: ['Topwater frogs', 'Spinnerbaits', 'Swimbaits', 'Texas-rigged worms'],
      baitsCold: ['Jigging spoons', 'Drop-shot rigs', 'Ned rigs', 'Blade baits'],
      techniqueWarm: 'Work shallow cover and structure. Slow-roll spinnerbaits at dawn.',
      techniqueCold: 'Slow presentations near deep structure. Finesse tactics work best.',
      depthWarm: 'Shallow (2–8 ft) near cover', depthCold: 'Deep (15–30 ft) near bottom',
    },
  },
  {
    id: 'smallmouth-bass',
    name: 'Smallmouth Bass',
    aliases: [],
    scientificName: 'Micropterus dolomieu',
    habitat: 'Freshwater',
    group: 'Bass',
    states: ['AL', 'AR', 'CO', 'GA', 'IA', 'IL', 'IN', 'KS', 'KY', 'MD', 'MI', 'MN', 'MO', 'MT', 'NC', 'NE', 'NY', 'OH', 'OK', 'PA', 'SD', 'TN', 'TX', 'VA', 'WV', 'WI', 'WY'],
    difficulty: 'Medium',
    record: 'Local record varies',
    image: '/fish/smallmouth-bass.jpg',
    imageAlt: 'Bronze smallmouth bass swimming over a rocky river bottom.',
    season: ['Spring', 'Summer', 'Fall'],
    bestBait: ['Tube jigs', 'Ned rigs', 'Jerkbaits', 'Crayfish'],
    bestTime: 'Early morning',
    depth: '3–20 ft',
    habitatNotes: 'Rocky rivers, shoals, and clear lakes',
    tips: 'Follow current seams and rock transitions; natural crayfish colors shine in clear water.',
    activity: [3, 4, 8, 9, 8, 7, 6, 6, 8, 8, 5, 3],
    advice: {
      optTempMin: 13, optTempMax: 23,
      baitsWarm: ['Tube jigs', 'Topwater walkers', 'Crayfish imitations'],
      baitsCold: ['Ned rigs', 'Hair jigs', 'Suspending jerkbaits'],
      techniqueWarm: 'Cast to current breaks and rocky shoals; vary cadence until fish commit.',
      techniqueCold: 'Work finesse baits slowly along deeper rock and gravel transitions.',
      depthWarm: 'Shallow rock and current seams (3–12 ft)', depthCold: 'Deep rock edges (12–25 ft)',
    },
  },
  {
    id: 'walleye',
    name: 'Walleye',
    aliases: [],
    scientificName: 'Sander vitreus',
    habitat: 'Freshwater',
    group: 'Walleye',
    states: ['AK', 'CO', 'IA', 'ID', 'IL', 'IN', 'KS', 'MI', 'MN', 'MO', 'MT', 'ND', 'NE', 'NY', 'OH', 'OK', 'OR', 'PA', 'SD', 'UT', 'WA', 'WI', 'WY'],
    difficulty: 'Medium',
    record: 'Local record varies',
    image: '/fish/walleye.jpg',
    imageAlt: 'Olive-gold walleye swimming above a rocky lake bottom.',
    season: ['Spring', 'Fall', 'Winter'],
    bestBait: ['Jigs with minnows', 'Nightcrawler harnesses', 'Crankbaits'],
    bestTime: 'Dusk & night',
    depth: '8–40 ft',
    habitatNotes: 'Rocky points, reefs, and break lines',
    tips: 'Use low-light windows and a controlled, near-bottom presentation around structure.',
    activity: [6, 7, 9, 8, 5, 4, 4, 5, 8, 9, 8, 7],
    advice: {
      optTempMin: 10, optTempMax: 18,
      baitsWarm: ['Jigs with live minnows', 'Nightcrawler harnesses', 'Crankbaits'],
      baitsCold: ['Jigging Raps', 'Blade baits', 'Live suckers'],
      techniqueWarm: 'Troll along structure at dusk and target rocky points.',
      techniqueCold: 'Vertically jig over deep structure with slow, deliberate lifts.',
      depthWarm: 'Mid-depth rocky structure (8–20 ft)', depthCold: 'Deep structure (20–40 ft)',
    },
  },
  {
    id: 'channel-catfish',
    name: 'Channel Catfish',
    aliases: [],
    scientificName: 'Ictalurus punctatus',
    habitat: 'Freshwater',
    group: 'Catfish',
    states: ['AL', 'AR', 'AZ', 'CA', 'CO', 'FL', 'GA', 'IA', 'IL', 'IN', 'KS', 'KY', 'LA', 'MD', 'MO', 'MS', 'NC', 'NE', 'NM', 'NY', 'OH', 'OK', 'PA', 'SC', 'SD', 'TN', 'TX', 'VA', 'WV'],
    difficulty: 'Easy',
    record: '58 lb',
    image: '/fish/channel-catfish.jpg',
    imageAlt: 'Spotted channel catfish swimming near a river-bottom channel.',
    season: ['Spring', 'Summer', 'Fall'],
    bestBait: ['Chicken liver', 'Stink bait', 'Nightcrawlers', 'Cut shad'],
    bestTime: 'Night',
    depth: '10–30 ft',
    habitatNotes: 'Deep holes and river bends',
    tips: 'Anchor above a channel edge and use fragrant bait to create a scent trail after dark.',
    activity: [3, 3, 5, 6, 8, 9, 9, 8, 7, 5, 4, 3],
    advice: {
      optTempMin: 21, optTempMax: 29,
      baitsWarm: ['Chicken liver', 'Nightcrawlers', 'Stink bait', 'Cut shad'],
      baitsCold: ['Live bream', 'Cut carp', 'Shrimp'],
      techniqueWarm: 'Bottom fish near channel edges at dusk and after dark.',
      techniqueCold: 'Target deep holes and ledges with slow, scent-rich presentations.',
      depthWarm: 'Mid-depth channel edges (5–15 ft)', depthCold: 'Deep holes (15–40 ft)',
    },
  },
  {
    id: 'blue-catfish',
    name: 'Blue Catfish',
    aliases: [],
    scientificName: 'Ictalurus furcatus',
    habitat: 'Freshwater',
    group: 'Catfish',
    states: ['AL', 'AR', 'AZ', 'CA', 'FL', 'GA', 'IL', 'IN', 'KS', 'KY', 'LA', 'MD', 'MO', 'MS', 'NC', 'NE', 'NM', 'NY', 'OH', 'OK', 'PA', 'SC', 'TN', 'TX', 'VA', 'WV'],
    difficulty: 'Medium',
    record: 'Local record varies',
    image: '/fish/blue-catfish.jpg',
    imageAlt: 'Blue-gray blue catfish swimming above a deep river channel.',
    season: ['Winter', 'Spring', 'Fall'],
    bestBait: ['Fresh cut shad', 'Skipjack', 'Live bait', 'Catfish punch bait'],
    bestTime: 'Morning',
    depth: '15–60 ft',
    habitatNotes: 'Major rivers, reservoirs, and channel ledges',
    tips: 'Use fresh oily cut bait and let sonar guide you to baitfish and deep channel structure.',
    activity: [8, 8, 8, 7, 6, 5, 5, 6, 7, 8, 9, 9],
    advice: {
      optTempMin: 12, optTempMax: 26,
      baitsWarm: ['Fresh cut shad', 'Skipjack', 'Live shad'],
      baitsCold: ['Fresh cut bait', 'Whole baitfish', 'Scented baits'],
      techniqueWarm: 'Drift fresh cut bait across channel flats and ledges near baitfish.',
      techniqueCold: 'Anchor on deep winter holes and soak large natural baits near bottom.',
      depthWarm: 'Channel ledges (12–35 ft)', depthCold: 'Deep river holes (30–60 ft)',
    },
  },
  {
    id: 'flathead-catfish',
    name: 'Flathead Catfish',
    aliases: ['Yellow Cat', 'Shovelhead'],
    scientificName: 'Pylodictis olivaris',
    habitat: 'Freshwater',
    group: 'Catfish',
    states: ['AL', 'AR', 'GA', 'IA', 'IL', 'IN', 'KS', 'KY', 'LA', 'MO', 'MS', 'NE', 'OK', 'OH', 'PA', 'SC', 'TN', 'TX', 'WV'],
    difficulty: 'Medium',
    record: '123 lb 9 oz',
    image: '/fish/channel-catfish.jpg',
    imageAlt: 'Flathead catfish resting on a sandy freshwater bottom.',
    season: ['Spring', 'Summer', 'Fall'],
    bestBait: ['Live sunfish', 'Live shad', 'Cut bait'],
    bestTime: 'Dusk & night',
    depth: '8–30 ft',
    habitatNotes: 'Deep pools, outside bends, and woody cover',
    tips: 'Anchor near deep current breaks after dark and keep a lively legal bait close to bottom.',
    activity: [3, 4, 6, 8, 9, 10, 10, 9, 8, 6, 4, 3],
    advice: {
      optTempMin: 18, optTempMax: 29,
      baitsWarm: ['Live sunfish', 'Live shad', 'Cut bait'],
      baitsCold: ['Cut bait', 'Live bait near deep cover'],
      techniqueWarm: 'Fish the deepest cover and current edges after sunset with stout tackle.',
      techniqueCold: 'Slowly work deep winter pools and river bends near the bottom.',
      depthWarm: 'Deep cover and outside bends (10–30 ft)', depthCold: 'Deep pools (15–40 ft)',
    },
  },
  {
    id: 'black-crappie',
    name: 'Black Crappie',
    aliases: ['Crappie'],
    scientificName: 'Pomoxis nigromaculatus',
    habitat: 'Freshwater',
    group: 'Panfish',
    states: ['AL', 'AR', 'AZ', 'CA', 'CO', 'FL', 'GA', 'IA', 'IL', 'IN', 'KS', 'KY', 'LA', 'MD', 'MI', 'MN', 'MO', 'MS', 'NC', 'NE', 'NM', 'NY', 'OH', 'OK', 'PA', 'SC', 'SD', 'TN', 'TX', 'VA', 'WI', 'WV'],
    difficulty: 'Easy',
    record: '5 lb 3 oz',
    image: '/fish/black-crappie.jpg',
    imageAlt: 'Speckled black crappie beside submerged freshwater brush.',
    season: ['Spring', 'Winter'],
    bestBait: ['Minnows', 'Jigs', 'Small spinners'],
    bestTime: 'Dawn',
    depth: '5–15 ft',
    habitatNotes: 'Brush piles, docks, and bridge cover',
    tips: 'Use electronics to locate suspended schools, then hold a tiny jig at their depth.',
    activity: [5, 4, 7, 9, 6, 4, 3, 3, 5, 6, 5, 5],
    advice: {
      optTempMin: 15, optTempMax: 23,
      baitsWarm: ['Small jigs (1/32 oz)', 'Minnows', 'Small spinners'],
      baitsCold: ['Tiny jigs', 'Small live minnows', 'Ice fishing jigs'],
      techniqueWarm: 'Slow vertical jig near brush piles, docks, and timber.',
      techniqueCold: 'Present tiny baits very slowly around deep brush and suspended schools.',
      depthWarm: 'Brush and cover (4–12 ft)', depthCold: 'Deep timber (15–25 ft)',
    },
  },
  {
    id: 'white-crappie',
    name: 'White Crappie',
    aliases: [],
    scientificName: 'Pomoxis annularis',
    habitat: 'Freshwater',
    group: 'Panfish',
    states: ['AL','AR','CO','FL','GA','IA','IL','IN','KS','KY','LA','MO','MS','NE','NM','NY','NC','OH','OK','PA','SC','SD','TN','TX','VA','WV'],
    difficulty: 'Easy',
    record: '5 lb 3 oz',
    image: '/fish/white-crappie.jpg',
    imageAlt: 'White crappie with vertical dark bars beside submerged lake brush.',
    season: ['Spring', 'Fall', 'Winter'],
    bestBait: ['Small jigs', 'Minnows', 'Tube jigs'],
    bestTime: 'Dawn & dusk', depth: '5–25 ft', habitatNotes: 'Brush piles, bridge pilings, and creek channels',
    tips: 'Use a small jig or minnow around submerged brush; follow suspended schools with sonar when available.',
    activity: [3, 5, 8, 9, 7, 5, 4, 5, 8, 8, 6, 5],
    advice: { optTempMin: 12, optTempMax: 23, baitsWarm: ['Minnows', 'Small jigs', 'Grubs'], baitsCold: ['Vertical jigs', 'Minnows', 'Blade baits'], techniqueWarm: 'Work brush and channel edges with a slow horizontal jig.', techniqueCold: 'Stay vertical over suspended fish and pause often.', depthWarm: 'Mid-depth (8–18 ft) around brush', depthCold: 'Deep (15–30 ft) over channels' },
  },
  {
    id: 'bluegill',
    name: 'Bluegill',
    aliases: [],
    scientificName: 'Lepomis macrochirus',
    habitat: 'Freshwater',
    group: 'Panfish',
    states: ['AL', 'AR', 'AZ', 'CA', 'CO', 'FL', 'GA', 'IA', 'IL', 'IN', 'KS', 'KY', 'LA', 'MD', 'MI', 'MN', 'MO', 'MS', 'NC', 'NE', 'NM', 'NY', 'OH', 'OK', 'PA', 'SC', 'SD', 'TN', 'TX', 'VA', 'WI', 'WV'],
    difficulty: 'Easy',
    record: '4 lb 12 oz',
    image: '/fish/bluegill.jpg',
    imageAlt: 'Blue-green bluegill among sunlit pond weeds.',
    season: ['Spring', 'Summer'],
    bestBait: ['Crickets', 'Worms', 'Small jigs', 'Poppers'],
    bestTime: 'Midday',
    depth: '1–8 ft',
    habitatNotes: 'Shallow weeds, docks, and bedding areas',
    tips: 'Use small hooks and light line; look for nesting colonies during late spring.',
    activity: [2, 2, 4, 6, 9, 9, 9, 8, 6, 4, 2, 2],
    advice: {
      optTempMin: 18, optTempMax: 28,
      baitsWarm: ['Crickets', 'Worms', 'Small jigs', 'Poppers'],
      baitsCold: ['Waxworms', 'Tiny jigs', 'Small pieces of worm'],
      techniqueWarm: 'Fish bedding areas and shallow cover with compact baits under a float.',
      techniqueCold: 'Slow small jigs along remaining green weeds and dock posts.',
      depthWarm: 'Shallow cover (1–6 ft)', depthCold: 'Edges and docks (5–12 ft)',
    },
  },
  {
    id: 'pumpkinseed',
    name: 'Pumpkinseed',
    aliases: ['Pumpkinseed Sunfish'],
    scientificName: 'Lepomis gibbosus',
    habitat: 'Freshwater',
    group: 'Panfish',
    states: ['AL','AR','CT','DE','FL','GA','IA','IL','IN','KS','KY','LA','MA','MD','ME','MI','MN','MO','MS','NC','NE','NH','NJ','NY','OH','OK','PA','RI','SC','TN','TX','VA','VT','WI','WV'],
    difficulty: 'Easy',
    record: '1 lb 8 oz',
    image: '/fish/pumpkinseed.jpg',
    imageAlt: 'Pumpkinseed sunfish with orange-red ear flap and blue facial markings in a weedy lake.',
    season: ['Spring', 'Summer', 'Fall'],
    bestBait: ['Worms', 'Small jigs', 'Crickets'],
    bestTime: 'Late morning', depth: '2–12 ft', habitatNotes: 'Weedy coves and quiet shoreline water',
    tips: 'Fish small baits around vegetation and docks; light tackle makes these colorful panfish especially fun.',
    activity: [3, 4, 7, 8, 9, 8, 7, 7, 6, 5, 3, 2],
    advice: { optTempMin: 16, optTempMax: 27, baitsWarm: ['Worms', 'Crickets', 'Small spinners'], baitsCold: ['Small jigs', 'Mealworms', 'Micro spoons'], techniqueWarm: 'Suspend a small bait near weeds and shade.', techniqueCold: 'Slow-jig near the first drop-off.', depthWarm: 'Shallow (2–8 ft) near vegetation', depthCold: 'Deeper (8–15 ft) near cover' },
  },
  {
    id: 'redear-sunfish',
    name: 'Redear Sunfish',
    aliases: ['Shellcracker'],
    scientificName: 'Lepomis microlophus',
    habitat: 'Freshwater',
    group: 'Panfish',
    states: ['AL','AR','AZ','CA','FL','GA','IL','IN','KS','KY','LA','MO','MS','NC','NM','OK','SC','TN','TX','VA'],
    difficulty: 'Medium',
    record: '6 lb 12 oz',
    image: '/fish/redear-sunfish.jpg',
    imageAlt: 'Redear sunfish with a red-orange operculum edge over a shallow lake bottom.',
    season: ['Spring', 'Summer'],
    bestBait: ['Worms', 'Crickets', 'Midges'],
    bestTime: 'Midday', depth: '3–15 ft', habitatNotes: 'Firm bottoms, vegetation, and warm shallow coves',
    tips: 'Target firm bottom areas during the spawn with small natural baits close to the lake floor.',
    activity: [3, 4, 8, 9, 9, 8, 7, 6, 5, 4, 3, 2],
    advice: { optTempMin: 18, optTempMax: 28, baitsWarm: ['Worms', 'Crickets', 'Small craws'], baitsCold: ['Midges', 'Small jigs', 'Worm pieces'], techniqueWarm: 'Keep a small bait tight to firm bottom near spawning areas.', techniqueCold: 'Work tiny jigs slowly along the bottom.', depthWarm: 'Shallow (3–8 ft) over firm bottom', depthCold: 'Mid-depth (10–18 ft) near structure' },
  },
  {
    id: 'green-sunfish',
    name: 'Green Sunfish',
    aliases: [],
    scientificName: 'Lepomis cyanellus',
    habitat: 'Freshwater',
    group: 'Panfish',
    states: ['AL','AR','AZ','CA','CO','FL','GA','IA','IL','IN','KS','KY','LA','MO','MS','NE','NM','NY','NC','OK','PA','SC','SD','TN','TX','VA','WI','WV'],
    difficulty: 'Easy',
    record: '2 lb 2 oz',
    image: '/fish/green-sunfish.jpg',
    imageAlt: 'Green sunfish with blue cheek markings near rocky freshwater cover.',
    season: ['Spring', 'Summer', 'Fall'],
    bestBait: ['Worms', 'Small spinners', 'Crickets'],
    bestTime: 'Morning', depth: '1–8 ft', habitatNotes: 'Rocky banks, brush, and small streams',
    tips: 'Look tight to shoreline cover; green sunfish readily take compact baits in current and ponds.',
    activity: [4, 5, 8, 9, 8, 7, 6, 6, 7, 6, 4, 3],
    advice: { optTempMin: 16, optTempMax: 28, baitsWarm: ['Worms', 'Crickets', 'Small spinners'], baitsCold: ['Tiny jigs', 'Worm pieces', 'Micro spoons'], techniqueWarm: 'Pitch a small bait beside rocks, brush, and undercut banks.', techniqueCold: 'Slowly twitch small jigs beside the deepest cover.', depthWarm: 'Shallow (1–6 ft) beside cover', depthCold: 'Deeper pockets (6–12 ft)' },
  },
  {
    id: 'warmouth',
    name: 'Warmouth',
    aliases: [],
    scientificName: 'Lepomis gulosus',
    habitat: 'Freshwater',
    group: 'Panfish',
    states: ['AL','AR','FL','GA','IL','IN','IA','KS','KY','LA','MO','MS','NC','OH','OK','SC','TN','TX','VA','WV'],
    difficulty: 'Easy',
    record: '2 lb 7 oz',
    image: '/fish/warmouth.jpg',
    imageAlt: 'Warmouth with dark lines radiating from the eye over a vegetation-lined bottom.',
    season: ['Spring', 'Summer', 'Fall'],
    bestBait: ['Worms', 'Crickets', 'Small craws'],
    bestTime: 'Dawn & dusk', depth: '2–12 ft', habitatNotes: 'Stump fields, muddy banks, and slow backwaters',
    tips: 'Probe shaded wood and soft-bottom backwaters with compact natural bait.',
    activity: [3, 4, 8, 9, 8, 7, 6, 6, 7, 6, 4, 2],
    advice: { optTempMin: 17, optTempMax: 28, baitsWarm: ['Worms', 'Crickets', 'Small craws'], baitsCold: ['Small jigs', 'Worm pieces', 'Micro crankbaits'], techniqueWarm: 'Work natural baits close to wood and shaded banks.', techniqueCold: 'Slowly hop a small jig through deeper cover.', depthWarm: 'Shallow (2–8 ft) near wood', depthCold: 'Mid-depth (8–15 ft) around cover' },
  },
  {
    id: 'yellow-bullhead', name: 'Yellow Bullhead', aliases: ['Yellow Catfish'], scientificName: 'Ameiurus natalis',
    habitat: 'Freshwater', group: 'Catfish', states: ['AL','AR','FL','GA','IL','IN','IA','KS','KY','LA','MD','MO','MS','NC','NE','NY','OH','OK','PA','SC','TN','TX','VA','WV'],
    difficulty: 'Easy', record: '6 lb 6 oz', image: '/fish/yellow-bullhead.jpg', imageAlt: 'Yellow bullhead catfish with a golden body, pale belly, and visible barbels in a pond.', season: ['Spring','Summer','Fall'], bestBait: ['Worms','Crickets','Cut bait'], bestTime: 'Dusk', depth: '2–15 ft', habitatNotes: 'Quiet ponds, backwaters, and small streams', tips: 'Use compact natural bait along shaded banks and slow current.', activity: [2,3,7,8,9,8,7,7,7,6,4,2], advice: { optTempMin: 17, optTempMax: 28, baitsWarm: ['Worms','Crickets','Cut bait'], baitsCold: ['Worms','Small jigs','Cut bait'], techniqueWarm: 'Keep bait tight to shaded cover and soft bottom.', techniqueCold: 'Slowly soak bait in deeper slack water.', depthWarm: 'Shallow (2–8 ft)', depthCold: 'Mid-depth (8–18 ft)' },
  },
  {
    id: 'black-bullhead', name: 'Black Bullhead', aliases: ['Black Catfish'], scientificName: 'Ameiurus melas',
    habitat: 'Freshwater', group: 'Catfish', states: ['AL','AR','AZ','CA','CO','FL','GA','IA','IL','IN','KS','KY','LA','MD','MI','MN','MO','MS','NE','NM','NY','NC','ND','OH','OK','PA','SC','SD','TN','TX','VA','WI','WV'],
    difficulty: 'Easy', record: '7 lb 1 oz', image: '/fish/black-bullhead.jpg', imageAlt: 'Black bullhead catfish with a dark body and whiskered mouth over a rocky lake bottom.', season: ['Spring','Summer','Fall'], bestBait: ['Worms','Dough bait','Cut bait'], bestTime: 'Night', depth: '3–18 ft', habitatNotes: 'Turbid ponds, reservoirs, and slow river margins', tips: 'Target warm, quiet water with natural bait after dark.', activity: [2,3,7,8,9,8,7,7,8,7,4,2], advice: { optTempMin: 17, optTempMax: 29, baitsWarm: ['Worms','Dough bait','Cut bait'], baitsCold: ['Worms','Cut bait','Small jigs'], techniqueWarm: 'Soak bait on the bottom near warm shoreline cover.', techniqueCold: 'Fish the deepest slow-water basin with a patient presentation.', depthWarm: 'Bottom (3–12 ft)', depthCold: 'Deep (10–20 ft)' },
  },
  {
    id: 'bigmouth-buffalo', name: 'Bigmouth Buffalo', aliases: ['Buffalo Fish'], scientificName: 'Ictiobus cyprinellus',
    habitat: 'Freshwater', group: 'Panfish', states: ['AL','AR','CO','GA','IA','IL','IN','KS','KY','LA','MI','MN','MO','MS','MT','NE','ND','OH','OK','SD','TN','TX','WI','WV'],
    difficulty: 'Medium', record: '73 lb 4 oz', image: '/fish/bigmouth-buffalo.jpg', imageAlt: 'Bigmouth buffalo with a bronze body and broad downturned mouth in a large river.', season: ['Spring','Summer','Fall'], bestBait: ['Dough bait','Worms','Corn'], bestTime: 'Morning', depth: '4–20 ft', habitatNotes: 'Large rivers, reservoirs, and floodplain backwaters', tips: 'Use bottom presentations near current seams and gently sloping flats.', activity: [2,4,8,9,8,7,6,6,7,6,3,2], advice: { optTempMin: 15, optTempMax: 25, baitsWarm: ['Dough bait','Corn','Worms'], baitsCold: ['Worms','Dough bait','Small jigs'], techniqueWarm: 'Anchor near a current seam and keep bait on bottom.', techniqueCold: 'Slowly present bait along the first deep break.', depthWarm: 'Bottom (4–14 ft)', depthCold: 'Deep (12–24 ft)' },
  },
  {
    id: 'smallmouth-buffalo', name: 'Smallmouth Buffalo', aliases: ['Buffalo'], scientificName: 'Ictiobus bubalus',
    habitat: 'Freshwater', group: 'Panfish', states: ['AL','AR','CO','FL','GA','IA','IL','IN','KS','KY','LA','MO','MS','NE','NM','OK','TN','TX','WV'],
    difficulty: 'Medium', record: '82 lb 0 oz', image: '/fish/smallmouth-buffalo.jpg', imageAlt: 'Smallmouth buffalo with a gray-bronze body and small mouth over a rocky riverbed.', season: ['Spring','Summer','Fall'], bestBait: ['Dough bait','Worms','Corn'], bestTime: 'Morning', depth: '4–20 ft', habitatNotes: 'Clearer rivers, pools, and reservoir channels', tips: 'Work bottom baits along gravel and current edges where schools feed.', activity: [2,4,8,9,8,7,6,6,7,6,3,2], advice: { optTempMin: 15, optTempMax: 25, baitsWarm: ['Dough bait','Corn','Worms'], baitsCold: ['Worms','Dough bait','Small jigs'], techniqueWarm: 'Present bait just downstream of a seam over gravel.', techniqueCold: 'Fish deeper pools with a slow bottom rig.', depthWarm: 'Bottom (4–14 ft)', depthCold: 'Deep (12–24 ft)' },
  },
  {
    id: 'black-buffalo', name: 'Black Buffalo', aliases: ['Blackfish'], scientificName: 'Ictiobus niger',
    habitat: 'Freshwater', group: 'Panfish', states: ['AL','AR','IL','IN','IA','KY','LA','MI','MO','MS','OH','OK','TN','TX','WI'],
    difficulty: 'Medium', record: '62 lb 0 oz', image: '/fish/black-buffalo.jpg', imageAlt: 'Black buffalo with a dark charcoal body and downturned mouth in clear river water.', season: ['Spring','Summer','Fall'], bestBait: ['Dough bait','Worms','Corn'], bestTime: 'Morning', depth: '5–24 ft', habitatNotes: 'Deep river pools and connected backwaters', tips: 'Find deep, slower water near clean gravel and keep the rig on bottom.', activity: [2,4,8,9,8,7,6,6,7,6,3,2], advice: { optTempMin: 15, optTempMax: 25, baitsWarm: ['Dough bait','Corn','Worms'], baitsCold: ['Worms','Dough bait','Small jigs'], techniqueWarm: 'Hold bait in a deep pool just off the main current.', techniqueCold: 'Use a slow bottom presentation near wintering water.', depthWarm: 'Bottom (5–16 ft)', depthCold: 'Deep (16–28 ft)' },
  },
  {
    id: 'freshwater-drum', name: 'Freshwater Drum', aliases: ['Sheepshead'], scientificName: 'Aplodinotus grunniens',
    habitat: 'Freshwater', group: 'Panfish', states: ['AL','AR','CO','FL','GA','IA','IL','IN','KS','KY','LA','MI','MN','MO','MS','MT','NE','ND','NY','OH','OK','PA','SD','TN','TX','WI','WV'],
    difficulty: 'Easy', record: '54 lb 8 oz', image: '/fish/freshwater-drum.jpg', imageAlt: 'Silver-gray freshwater drum over a rocky river bottom with its rounded body in profile.', season: ['Spring','Summer','Fall'], bestBait: ['Nightcrawlers','Minnows','Crayfish'], bestTime: 'Dawn & dusk', depth: '5–30 ft', habitatNotes: 'Rocky rivers, reservoirs, and deep current breaks', tips: 'Bounce natural bait near rock and current seams for steady action.', activity: [2,4,8,9,8,7,6,6,7,7,4,2], advice: { optTempMin: 14, optTempMax: 25, baitsWarm: ['Nightcrawlers','Minnows','Crayfish'], baitsCold: ['Worms','Minnows','Small jigs'], techniqueWarm: 'Drift bait along rocky current seams.', techniqueCold: 'Work a small bait slowly along deeper rock.', depthWarm: 'Mid-depth (8–20 ft)', depthCold: 'Deep (18–35 ft)' },
  },
  {
    id: 'white-bass', name: 'White Bass', aliases: ['Silver Bass'], scientificName: 'Morone chrysops',
    habitat: 'Freshwater', group: 'Bass', states: ['AL','AR','CO','GA','IA','IL','IN','KS','KY','LA','MI','MO','MS','NE','NM','NY','NC','OH','OK','PA','SD','TN','TX','VA','WV','WI'],
    difficulty: 'Easy', record: '6 lb 11 oz', image: '/fish/white-bass.jpg', imageAlt: 'Silvery white bass with faint horizontal stripes over rocky reservoir water.', season: ['Spring','Summer','Fall'], bestBait: ['Small jigs','Minnows','Blade baits'], bestTime: 'Dawn & dusk', depth: '5–25 ft', habitatNotes: 'Reservoir points, open water, and river spawning runs', tips: 'Follow schooling fish with sonar or birds and keep moving until you find them.', activity: [3,6,9,9,8,7,6,6,8,7,4,2], advice: { optTempMin: 14, optTempMax: 25, baitsWarm: ['Small jigs','Minnows','Blade baits'], baitsCold: ['Blade baits','Minnows','Jigs'], techniqueWarm: 'Fan-cast schooling areas and vary retrieve speed.', techniqueCold: 'Keep a blade bait close to deep structure.', depthWarm: 'Mid-depth (8–20 ft)', depthCold: 'Deep (18–30 ft)' },
  },
  {
    id: 'sauger', name: 'Sauger', aliases: [], scientificName: 'Sander canadensis',
    habitat: 'Freshwater', group: 'Walleye', states: ['AL','AR','IA','IL','IN','KS','KY','LA','MI','MN','MO','MS','MT','ND','NE','NY','OH','OK','PA','SD','TN','TX','WI','WV'],
    difficulty: 'Medium', record: '17 lb 3 oz', image: '/fish/sauger.jpg', imageAlt: 'Olive-gold sauger with dark saddle markings and glassy eyes over a rocky river bottom.', season: ['Spring','Fall','Winter'], bestBait: ['Jigs','Minnows','Blade baits'], bestTime: 'Dawn & dusk', depth: '8–30 ft', habitatNotes: 'Deep rivers, tailwaters, and current breaks', tips: 'Keep a jig close to bottom and focus on seams where current meets slack water.', activity: [3,5,8,7,5,4,4,5,8,8,6,5], advice: { optTempMin: 6, optTempMax: 18, baitsWarm: ['Jigs','Minnows','Blade baits'], baitsCold: ['Jigs','Minnows','Blade baits'], techniqueWarm: 'Drift or troll a jig along deep current seams.', techniqueCold: 'Slow-bounce a tipped jig close to bottom.', depthWarm: 'Deep (10–24 ft)', depthCold: 'Deep (18–35 ft)' },
  },
  {
    id: 'paddlefish', name: 'Paddlefish', aliases: ['Spoonbill'], scientificName: 'Polyodon spathula',
    habitat: 'Freshwater', group: 'Walleye', states: ['AL','AR','IL','IN','IA','KS','KY','LA','MO','MS','MT','NE','NY','ND','OH','OK','PA','SD','TN','TX','WV','WI'],
    difficulty: 'Hard', record: '144 lb 0 oz', image: '/fish/paddlefish.jpg', imageAlt: 'Large silver American paddlefish with a distinctive long paddle-shaped snout in a broad river.', season: ['Spring','Summer','Fall'], bestBait: ['Regulation-dependent snagging gear'], bestTime: 'Morning', depth: '15–60 ft', habitatNotes: 'Large rivers, reservoirs, and deep current channels', tips: 'Follow local regulations carefully; target legal seasons and deep open-water concentrations.', activity: [2,4,7,9,8,7,6,6,7,6,3,2], advice: { optTempMin: 12, optTempMax: 24, baitsWarm: ['Legal paddlefish gear'], baitsCold: ['Legal paddlefish gear'], techniqueWarm: 'Use only legal methods around deep current and spawning migrations.', techniqueCold: 'Check seasonal regulations before targeting deep winter concentrations.', depthWarm: 'Deep (15–45 ft)', depthCold: 'Very deep (30–70 ft)' },
  },
  {
    id: 'rainbow-trout',
    name: 'Rainbow Trout',
    aliases: [],
    scientificName: 'Oncorhynchus mykiss',
    habitat: 'Freshwater',
    group: 'Trout',
    states: ['AK', 'AZ', 'CA', 'CO', 'CT', 'ID', 'ME', 'MD', 'MA', 'MI', 'MN', 'MT', 'NH', 'NJ', 'NM', 'NY', 'NC', 'OH', 'OK', 'OR', 'PA', 'RI', 'UT', 'VT', 'VA', 'WA', 'WV', 'WI', 'WY'],
    difficulty: 'Medium',
    record: 'Local record varies',
    image: '/fish/rainbow-trout.jpg',
    imageAlt: 'Rainbow trout with a pink stripe in a clear mountain stream.',
    season: ['Spring', 'Fall', 'Winter'],
    bestBait: ['Inline spinners', 'Salmon eggs', 'Nymphs', 'Small jigs'],
    bestTime: 'Morning',
    depth: '1–12 ft',
    habitatNotes: 'Cold rivers, tailwaters, and small lakes — ODWC stocks rainbow trout at Medicine Creek (Medicine Park, Nov 1–Mar 15), Blue River, Lower Illinois River, Lower Mountain Fork River, Robbers Cave, Lake Carl Blackwell Turtle Pond, Sunset Lake, Lake Watonga, and Close-to-Home ponds in OKC, Jenks, and Broken Arrow',
    tips: 'Match stream insects or drift a subtle bait naturally through seams and pools.',
    activity: [7, 8, 9, 8, 5, 3, 3, 4, 7, 9, 9, 8],
    advice: {
      optTempMin: 8, optTempMax: 18,
      baitsWarm: ['Inline spinners', 'Salmon eggs', 'Elk Hair Caddis flies'],
      baitsCold: ['Midge patterns', 'Scuds', 'Small jigs', 'Mealworms'],
      techniqueWarm: 'Cast upstream and drift naturally through riffles and pools.',
      techniqueCold: 'Nymph near bottom with a slow drift in deep pools.',
      depthWarm: 'Shallow riffles (1–4 ft)', depthCold: 'Deep pools (4–12 ft)',
    },
  },
  {
    id: 'brown-trout',
    name: 'Brown Trout',
    aliases: [],
    scientificName: 'Salmo trutta',
    habitat: 'Freshwater',
    group: 'Trout',
    states: ['AK', 'AZ', 'CA', 'CO', 'CT', 'ID', 'ME', 'MD', 'MA', 'MI', 'MN', 'MT', 'NH', 'NJ', 'NM', 'NY', 'NC', 'OH', 'OK', 'OR', 'PA', 'RI', 'UT', 'VT', 'VA', 'WA', 'WV', 'WI', 'WY'],
    difficulty: 'Hard',
    record: 'Local record varies',
    image: '/fish/brown-trout.jpg',
    imageAlt: 'Golden brown trout with red and black spots in a cool river pool.',
    season: ['Fall', 'Winter', 'Spring'],
    bestBait: ['Streamers', 'Spinners', 'Nightcrawlers', 'Nymphs'],
    bestTime: 'Dusk',
    depth: '2–15 ft',
    habitatNotes: 'Cold streams, undercut banks, and tailwaters — ODWC stocks brown trout at the Lower Mountain Fork River, Lower Illinois River, and Blue River when available',
    tips: 'Approach quietly and work undercut banks, woody cover, and evening feeding lanes.',
    activity: [7, 8, 8, 7, 4, 3, 3, 4, 8, 10, 9, 8],
    advice: {
      optTempMin: 7, optTempMax: 17,
      baitsWarm: ['Streamers', 'Terrestrials', 'Inline spinners'],
      baitsCold: ['Nymphs', 'Egg patterns', 'Small jigs'],
      techniqueWarm: 'Probe shaded banks and cover during dawn, dusk, and overcast weather.',
      techniqueCold: 'Dead-drift compact nymphs along slower winter holding water.',
      depthWarm: 'Undercut banks and seams (2–8 ft)', depthCold: 'Deep pools (5–15 ft)',
    },
  },
  {
    id: 'bowfin', name: 'Bowfin', aliases: ['Dogfish'], scientificName: 'Amia calva',
    habitat: 'Freshwater', group: 'Pike', states: ['AL','AR','FL','GA','IL','IN','IA','KY','LA','MI','MN','MO','MS','NC','OH','OK','PA','SC','TN','TX','VA','WI'],
    difficulty: 'Medium', record: '21 lb 8 oz', image: '/fish/bowfin.jpg', imageAlt: 'Olive-mottled bowfin with a long dorsal fin and tail spot in a vegetated backwater.', season: ['Spring','Summer','Fall'], bestBait: ['Live minnows','Spinnerbaits','Soft plastics'], bestTime: 'Morning', depth: '2–12 ft', habitatNotes: 'Vegetated backwaters, swamps, and quiet lake coves', tips: 'Target dense vegetation with weed-resistant lures and live bait.', activity: [3,5,8,9,8,7,6,6,7,6,4,2], advice: { optTempMin: 18, optTempMax: 29, baitsWarm: ['Live minnows','Spinnerbaits','Soft plastics'], baitsCold: ['Slow swimbaits','Minnows','Jigs'], techniqueWarm: 'Work weed edges and pockets with a strong single-hook lure.', techniqueCold: 'Slowly suspend bait near the deepest vegetation.', depthWarm: 'Shallow (2–8 ft) in weeds', depthCold: 'Mid-depth (8–15 ft)' },
  },
  {
    id: 'longnose-gar', name: 'Longnose Gar', aliases: ['Gar'], scientificName: 'Lepisosteus osseus',
    habitat: 'Freshwater', group: 'Pike', states: ['AL','AR','FL','GA','IL','IN','IA','KS','KY','LA','MD','MO','MS','NC','NE','NJ','NY','OH','OK','PA','SC','TN','TX','VA','WV'],
    difficulty: 'Medium', record: '50 lb 5 oz', image: '/fish/longnose-gar.jpg', imageAlt: 'Longnose gar with an elongated snout and armored scales in clear slow-moving river water.', season: ['Spring','Summer','Fall'], bestBait: ['Live minnows','Cut bait','Surface plugs'], bestTime: 'Midday', depth: '2–15 ft', habitatNotes: 'Warm rivers, oxbows, and quiet reservoir margins', tips: 'Watch for surface cruising fish and lead a bait or lure well ahead of them.', activity: [3,5,8,9,8,7,6,6,7,6,4,2], advice: { optTempMin: 18, optTempMax: 30, baitsWarm: ['Live minnows','Cut bait','Surface plugs'], baitsCold: ['Slow minnows','Jigs','Cut bait'], techniqueWarm: 'Cast beyond cruising fish and retrieve across their path.', techniqueCold: 'Present bait slowly near deep wintering structure.', depthWarm: 'Shallow to mid-depth (2–12 ft)', depthCold: 'Deep (10–20 ft)' },
  },
  {
    id: 'common-carp', name: 'Common Carp', aliases: ['Carp'], scientificName: 'Cyprinus carpio',
    habitat: 'Freshwater', group: 'Panfish', states: ['AL','AK','AZ','AR','CA','CO','CT','DE','FL','GA','ID','IL','IN','IA','KS','KY','LA','ME','MD','MA','MI','MN','MS','MO','MT','NE','NV','NH','NJ','NM','NY','NC','ND','OH','OK','OR','PA','RI','SC','SD','TN','TX','UT','VT','VA','WA','WV','WI','WY'],
    difficulty: 'Medium', record: '75 lb 11 oz', image: '/fish/common-carp.jpg', imageAlt: 'Golden bronze common carp with barbels held over a lake shoreline.', season: ['Spring','Summer','Fall'], bestBait: ['Corn','Dough bait','Bread'], bestTime: 'Morning', depth: '2–18 ft', habitatNotes: 'Lakes, ponds, canals, and slow rivers', tips: 'Chum lightly, watch for mud plumes, and present bait on the bottom.', activity: [2,5,8,9,8,7,6,6,8,7,4,2], advice: { optTempMin: 16, optTempMax: 27, baitsWarm: ['Corn','Dough bait','Bread'], baitsCold: ['Corn','Worms','Dough bait'], techniqueWarm: 'Present a small bait on bottom near feeding carp.', techniqueCold: 'Fish slowly on sunny shallow flats during warm windows.', depthWarm: 'Shallow (2–10 ft)', depthCold: 'Mid-depth (8–20 ft)' },
  },
] as const satisfies readonly Species[];

export type SpeciesName = (typeof SPECIES)[number]['name'];

export const SPECIES_NAMES: readonly SpeciesName[] = SPECIES.map((species) => species.name);

export const SPECIES_BY_NAME: Readonly<Record<string, Species>> = Object.fromEntries(
  SPECIES.map((species) => [species.name, species]),
) as Record<string, Species>;

export function findSpecies(name: string): Species | undefined {
  const normalizedName = name.trim().toLocaleLowerCase();

  return SPECIES.find((species) =>
    species.name.toLocaleLowerCase() === normalizedName ||
    species.aliases.some((alias) => alias.toLocaleLowerCase() === normalizedName),
  );
}
