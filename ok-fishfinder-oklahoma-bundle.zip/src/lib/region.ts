import type { NorthAmericanState, Species } from '@/lib/speciesCatalog';

export interface Coordinates { latitude: number; longitude: number }

// Oklahoma is the app's only supported region: the map, spots, species catalog,
// and public access data are all scoped to Oklahoma.
export const OKLAHOMA_CENTER: Coordinates = { latitude: 35.5, longitude: -97.5 };
export const OKLAHOMA_STATE: NorthAmericanState = 'OK';

export function stateFromCoordinates({ latitude, longitude }: Coordinates): NorthAmericanState | null {
  if (latitude >= 33.6 && latitude <= 37.1 && longitude >= -103.1 && longitude <= -94.4) return 'OK';
  return null;
}

export function speciesForCoordinates(species: readonly Species[], coordinates?: Coordinates | null) {
  const oklahomaSpecies = species.filter((item) => item.states.includes(OKLAHOMA_STATE));
  const state = coordinates ? stateFromCoordinates(coordinates) : null;
  // Oklahoma-only focus: coordinates outside Oklahoma (or unavailable) fall
  // back to the Oklahoma species list instead of the full nationwide catalog.
  return state ? species.filter((item) => item.states.includes(state)) : oklahomaSpecies;
}

export function requestDeviceLocation(onResult: (coordinates: Coordinates | null) => void) {
  if (typeof navigator === 'undefined' || !navigator.geolocation) { onResult(null); return () => {}; }
  let active = true;
  navigator.geolocation.getCurrentPosition(
    (position) => { if (active) onResult({ latitude: position.coords.latitude, longitude: position.coords.longitude }); },
    () => { if (active) onResult(null); },
    { enableHighAccuracy: false, timeout: 8000, maximumAge: 300000 },
  );
  return () => { active = false; };
}
