export interface DirectionsTarget {
  name: string;
  lat: number;
  lng: number;
}

export interface DirectionsOrigin {
  latitude: number;
  longitude: number;
}

export type DirectionsMode = 'driving' | 'walking' | 'bicycling';

/**
 * Universal cross-platform directions URL (Google Maps). When no origin is
 * provided, Google Maps asks the user for a start point — so the link still
 * works when device location permission is denied.
 */
export function googleMapsDirectionsUrl(
  target: DirectionsTarget,
  origin?: DirectionsOrigin | null,
  mode: DirectionsMode = 'driving',
): string {
  const params = new URLSearchParams({
    api: '1',
    destination: `${target.lat},${target.lng}`,
    travelmode: mode,
  });
  if (origin) {
    params.set('origin', `${origin.latitude},${origin.longitude}`);
  }
  return `https://www.google.com/maps/dir/?${params.toString()}`;
}

/**
 * Native geo intent fallback (Android). Most mobile browsers route the
 * Google Maps URL above into the installed maps app automatically, so this
 * is only a last resort.
 */
export function geoIntentUrl(target: DirectionsTarget): string {
  return `geo:${target.lat},${target.lng}?q=${encodeURIComponent(target.name)}`;
}
