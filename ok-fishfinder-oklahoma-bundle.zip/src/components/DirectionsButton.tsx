'use client';

import { useState } from 'react';
import { googleMapsDirectionsUrl, type DirectionsOrigin } from '@/lib/directions';

/**
 * One-tap "Directions" button: grabs the device GPS fix, then opens
 * turn-by-turn navigation to the spot. If location permission is denied
 * (or unavailable), it opens directions without a fixed origin so the maps
 * app prompts the user for a start point instead of failing.
 */
export default function DirectionsButton({
  name,
  lat,
  lng,
  compact = false,
}: {
  name: string;
  lat: number;
  lng: number;
  compact?: boolean;
}) {
  const [state, setState] = useState<'idle' | 'locating' | 'no-location'>('idle');

  const open = (origin?: DirectionsOrigin) => {
    window.open(
      googleMapsDirectionsUrl({ name, lat, lng }, origin ?? null),
      '_blank',
      'noopener,noreferrer',
    );
  };

  const handleClick = () => {
    if (typeof navigator === 'undefined' || !navigator.geolocation) {
      open();
      return;
    }
    setState('locating');
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setState('idle');
        open({ latitude: position.coords.latitude, longitude: position.coords.longitude });
      },
      () => {
        setState('no-location');
        open();
      },
      { enableHighAccuracy: true, timeout: 8000, maximumAge: 300_000 },
    );
  };

  const label =
    state === 'locating'
      ? 'Locating you…'
      : state === 'no-location'
        ? '🧭 Directions (set start point in maps)'
        : '🧭 Directions';

  return (
    <button
      type="button"
      onClick={handleClick}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: 6,
        background: 'linear-gradient(135deg,#0f766e,#0e7490)',
        color: 'white',
        border: '1px solid #14b8a6',
        borderRadius: 999,
        padding: compact ? '4px 10px' : '7px 14px',
        fontSize: compact ? 11 : 12,
        fontWeight: 800,
        cursor: 'pointer',
      }}
    >
      {label}
    </button>
  );
}
