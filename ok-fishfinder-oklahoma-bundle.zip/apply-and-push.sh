#!/usr/bin/env bash
# apply-and-push.sh — Oklahoma Fishfinder Pro changes
# Run from the root of your Fishfinder-pro clone:
#   bash apply-and-push.sh
set -euo pipefail

if [ ! -d .git ]; then
  echo "ERROR: run this from the root of your Fishfinder-pro git clone." >&2
  exit 1
fi

echo "==> Copying new/updated files into place"
cp -v ok-fishfinder-oklahoma-bundle/src/lib/defaultSpots.ts          src/lib/defaultSpots.ts
cp -v ok-fishfinder-oklahoma-bundle/src/lib/region.ts                src/lib/region.ts
cp -v ok-fishfinder-oklahoma-bundle/src/lib/speciesCatalog.ts        src/lib/speciesCatalog.ts
cp -v ok-fishfinder-oklahoma-bundle/src/lib/publicAccess.ts          src/lib/publicAccess.ts
cp -v ok-fishfinder-oklahoma-bundle/src/lib/directions.ts            src/lib/directions.ts
cp -v ok-fishfinder-oklahoma-bundle/src/app/layout.tsx               src/app/layout.tsx
cp -v ok-fishfinder-oklahoma-bundle/src/components/DirectionsButton.tsx     src/components/DirectionsButton.tsx
cp -v ok-fishfinder-oklahoma-bundle/src/components/PublicAccessPanel.tsx    src/components/PublicAccessPanel.tsx
cp -v ok-fishfinder-oklahoma-bundle/scripts/scrape-oklahoma-access.mjs      scripts/scrape-oklahoma-access.mjs
cp -v ok-fishfinder-oklahoma-bundle/docs/PUBLIC_ACCESS_DATA.md       docs/PUBLIC_ACCESS_DATA.md
cp -v ok-fishfinder-oklahoma-bundle/package.json                     package.json

echo "==> Patching src/app/page.tsx (rename header to Oklahoma FishFinder Pro)"
python3 - <<'PYEOF'
path = 'src/app/page.tsx'
s = open(path).read()
old = "WebkitTextFillColor:'transparent' }}>FishFinder Pro</span>"
new = "WebkitTextFillColor:'transparent' }}>Oklahoma FishFinder Pro</span>"
assert old in s, 'page.tsx header anchor not found — patch manually (see page-header-rename.patch.md)'
s = s.replace(old, new, 1)
open(path, 'w').write(s)
print('  page.tsx patched')
PYEOF

echo "==> Patching src/components/MapWrapper.tsx (Directions button in spot popup)"
python3 - <<'PYEOF'
path = 'src/components/MapWrapper.tsx'
s = open(path).read()
anchor_import = "import CatchLogger from '@/components/logbook/CatchLogger';"
assert anchor_import in s, 'MapWrapper import anchor not found'
if 'DirectionsButton' not in s:
    s = s.replace(anchor_import, anchor_import + "\nimport DirectionsButton from '@/components/DirectionsButton';", 1)
anchor_jsx = "<div style={{ fontSize: 11, color: '#94a3b8', marginTop: 3 }}>{spot.water_type} • {spot.spot_type}</div>\n                    </div>"
assert anchor_jsx in s, 'MapWrapper popup header anchor not found'
insert = anchor_jsx + "\n\n                    <div style={{ marginBottom: 10 }}>\n                      <DirectionsButton name={spot.name} lat={spot.lat} lng={spot.lng} compact />\n                    </div>"
s = s.replace(anchor_jsx, insert, 1)
open(path, 'w').write(s)
print('  MapWrapper.tsx patched')
PYEOF

echo "==> Sanity checks"
grep -q "Oklahoma FishFinder Pro" src/app/page.tsx
grep -q "DirectionsButton" src/components/MapWrapper.tsx
grep -q "medicine-creek-trout-area" src/lib/publicAccess.ts
node -e "const p=require('./package.json'); if(!p.scripts['scrape:ok-access']) throw new Error('missing scrape script')"
echo "  all checks passed"

echo "==> Committing and pushing to main"
git add src/lib/defaultSpots.ts src/lib/region.ts src/lib/speciesCatalog.ts \
        src/lib/publicAccess.ts src/lib/directions.ts src/app/layout.tsx \
        src/app/page.tsx src/components/DirectionsButton.tsx \
        src/components/PublicAccessPanel.tsx src/components/MapWrapper.tsx \
        scripts/scrape-oklahoma-access.mjs docs/PUBLIC_ACCESS_DATA.md package.json
git commit -m "Oklahoma-only focus: rename app, OK species catalog, 31 official access points, directions + official-source scraper

- Rename app to Oklahoma Fishfinder Pro (layout, package.json, page header)
- Species catalog trimmed to 27 species found in OK waters; ODWC-stocked trout added
- defaultSpots: 42 Oklahoma-only map fixtures (out-of-state removed)
- publicAccess: 31 official access points incl. Medicine Creek Trout Area
- Directions button: device GPS -> turn-by-turn to selected spot (map popup + access panel)
- scripts/scrape-oklahoma-access.mjs: OSM/Overpass + ODWC + RIDB (no Fishbrain)
- region.ts: OK-only species fallback"
git push origin main
echo "==> Done. Pushed to main."
