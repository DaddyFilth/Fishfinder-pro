#!/usr/bin/env node
/**
 * scrape-oklahoma-access.mjs
 *
 * Collects Oklahoma public fishing access candidates from OFFICIAL and
 * open-license sources only — no Fishbrain or other community platforms
 * (their terms prohibit scraping, and community data must never overwrite
 * official records).
 *
 * Sources:
 *   1. OpenStreetMap via the Overpass API (ODbL) — boat ramps, fishing spots,
 *      fishing-access nodes, with coordinates. Primary coordinate source.
 *   2. Oklahoma Department of Wildlife Conservation — official lake/area pages
 *      (access notes + verification URLs; coordinates when published).
 *   3. Recreation.gov RIDB API (optional, set RIDB_API_KEY) — federal sites.
 *
 * Output: data/oklahoma-access-scraped.json (review queue) + console report.
 * Nothing is auto-merged into src/lib/publicAccess.ts — review candidates,
 * then promote them with verificationStatus 'official'/'needs_verification'.
 *
 * Usage:
 *   node scripts/scrape-oklahoma-access.mjs
 *   node scripts/scrape-oklahoma-access.mjs --skip-overpass --skip-odwc
 */
import { writeFile, mkdir } from 'node:fs/promises';

const OK_BOUNDS = { minLat: 33.6, maxLat: 37.1, minLng: -103.1, maxLng: -94.4 };
const USER_AGENT = 'OklahomaFishfinderPro-AccessScraper/1.0 (official data collection)';
const TODAY = new Date().toISOString().slice(0, 10);
const args = new Set(process.argv.slice(2));

const inBounds = (lat, lng) =>
  lat >= OK_BOUNDS.minLat && lat <= OK_BOUNDS.maxLat && lng >= OK_BOUNDS.minLng && lng <= OK_BOUNDS.maxLng;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function fetchText(url, { headers = {} } = {}) {
  const res = await fetch(url, {
    headers: { 'User-Agent': USER_AGENT, Accept: 'text/html,application/json', ...headers },
    signal: AbortSignal.timeout(20_000),
  });
  if (!res.ok) throw new Error(`${res.status} ${url}`);
  return res.text();
}

const slugify = (s) =>
  s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '').slice(0, 60) || 'unnamed';

/* ---------------------------------------------------------------- Overpass */

async function scrapeOverpass() {
  const query = `[out:json][timeout:30];
(
  node["leisure"="slipway"](${OK_BOUNDS.minLat},${OK_BOUNDS.minLng},${OK_BOUNDS.maxLat},${OK_BOUNDS.maxLng});
  way["leisure"="slipway"](${OK_BOUNDS.minLat},${OK_BOUNDS.minLng},${OK_BOUNDS.maxLat},${OK_BOUNDS.maxLng});
  node["leisure"="fishing"](${OK_BOUNDS.minLat},${OK_BOUNDS.minLng},${OK_BOUNDS.maxLat},${OK_BOUNDS.maxLng});
  node["sport"="fishing"](${OK_BOUNDS.minLat},${OK_BOUNDS.minLng},${OK_BOUNDS.maxLat},${OK_BOUNDS.maxLng});
  node["fishing"="yes"](${OK_BOUNDS.minLat},${OK_BOUNDS.minLng},${OK_BOUNDS.maxLat},${OK_BOUNDS.maxLng});
);
out center tags;`;

  const res = await fetch('https://overpass-api.de/api/interpreter', {
    method: 'POST',
    headers: { 'User-Agent': USER_AGENT, 'Content-Type': 'application/x-www-form-urlencoded' },
    body: `data=${encodeURIComponent(query)}`,
    signal: AbortSignal.timeout(45_000),
  });
  if (!res.ok) throw new Error(`Overpass ${res.status}`);
  const json = await res.json();

  return (json.elements ?? [])
    .map((el) => ({
      name: el.tags?.name ?? null,
      lat: el.lat ?? el.center?.lat,
      lng: el.lon ?? el.center?.lon,
      accessType: el.tags?.leisure === 'slipway' ? 'boat_ramp' : 'shoreline',
      sourceName: 'OpenStreetMap contributors (ODbL)',
      sourceUrl: `https://www.openstreetmap.org/${el.type}/${el.id}`,
    }))
    .filter((p) => p.name && p.lat && p.lng && inBounds(p.lat, p.lng));
}

/* ------------------------------------------------------------------- ODWC */

const ODWC_REGIONS = ['central', 'southeast', 'northeast', 'northwest', 'southwest'];
const ODWC_BASE = 'https://www.wildlifedepartment.com';
const ODWC_AREAS = `${ODWC_BASE}/fishing/regs/department-fishing-areas`;

// "lat, lng" or "lat,lng" inside an Oklahoma-valid range.
const COORD_RE = /(-?\d{2,3}\.\d{3,})\s*,\s*(-?\d{2,3}\.\d{3,})/g;

function extractCoords(html) {
  const hits = [];
  for (const m of html.matchAll(COORD_RE)) {
    const lat = Number(m[1]);
    const lng = Number(m[2]);
    // Oklahoma-valid pairs: lat 33–38, lng -94..-104 (either order in text).
    if (lat >= 33 && lat <= 38 && lng >= -104 && lng <= -94) hits.push({ lat, lng });
    else if (lng >= 33 && lng <= 38 && lat >= -104 && lat <= -94) hits.push({ lat: lng, lng: lat });
  }
  return hits[0] ?? null;
}

async function scrapeOdwc() {
  const found = new Map(); // url -> point

  // 1) Department fishing areas index + each region's where-to-fish page.
  const indexPages = [ODWC_AREAS, ...ODWC_REGIONS.map((r) => `${ODWC_BASE}/fishing/wheretofish/${r}`)];
  const links = new Set();
  for (const page of indexPages) {
    try {
      const html = await fetchText(page);
      for (const m of html.matchAll(/href="(\/fishing\/(?:wheretofish|areas)\/[a-z0-9\-\/]+)"/gi)) {
        links.add(`${ODWC_BASE}${m[1]}`);
      }
    } catch (e) {
      console.warn(`  index fetch failed: ${e.message}`);
    }
    await sleep(400); // be polite
  }

  // 2) Fetch each linked area page; pull a name and published coordinates.
  const urls = [...links];
  console.log(`  ODWC: ${urls.length} area pages discovered`);
  let i = 0;
  for (const url of urls) {
    i += 1;
    try {
      const html = await fetchText(url);
      const title =
        html.match(/<h1[^>]*>([^<]+)<\/h1>/i)?.[1]?.trim() ??
        html.match(/<title>([^<|]+)/i)?.[1]?.trim() ??
        null;
      const coords = extractCoords(html);
      if (title && coords && inBounds(coords.lat, coords.lng)) {
        found.set(url, {
          name: title,
          lat: coords.lat,
          lng: coords.lng,
          accessType: 'shoreline',
          sourceName: 'Oklahoma Department of Wildlife Conservation',
          sourceUrl: url,
          verificationStatus: 'official',
        });
      }
    } catch { /* page failed; skip */ }
    if (i % 5 === 0) await sleep(500); // gentle pacing
  }
  return [...found.values()];
}

/* ------------------------------------------------------------------- RIDB */

async function scrapeRidb() {
  const key = process.env.RIDB_API_KEY;
  if (!key) return [];
  const res = await fetch(
    'https://ridb.recreation.gov/api/v1/facilities?state=OK&activity=22&limit=100',
    { headers: { 'User-Agent': USER_AGENT, apikey: key }, signal: AbortSignal.timeout(20_000) },
  );
  if (!res.ok) throw new Error(`RIDB ${res.status}`);
  const json = await res.json();
  return (json.RECDATA ?? [])
    .map((f) => ({
      name: f.FacilityName,
      lat: Number(f.FacilityLatitude) || null,
      lng: Number(f.FacilityLongitude) || null,
      accessType: 'shoreline',
      sourceName: 'Recreation.gov (RIDB)',
      sourceUrl: `https://www.recreation.gov/${f.FacilityID ? `site/facility/${f.FacilityID}` : ''}`,
    }))
    .filter((p) => p.name && p.lat && p.lng && inBounds(p.lat, p.lng));
}

/* ------------------------------------------------------------------ merge */

const haversineM = (a, b) => {
  const R = 6371000, toRad = (d) => (d * Math.PI) / 180;
  const dLat = toRad(b.lat - a.lat), dLng = toRad(b.lng - a.lng);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
};

function toAccessPoint(p, seen) {
  // Dedupe anything within 250 m of an already-kept point.
  if (seen.some((s) => haversineM(s, p) < 250)) return null;
  seen.push(p);
  return {
    id: `${slugify(p.name)}-access`,
    spotName: p.name,
    waterBody: p.name,
    city: '',
    state: 'OK',
    latitude: Number(p.lat.toFixed(6)),
    longitude: Number(p.lng.toFixed(6)),
    publicAccess: true,
    accessType: p.accessType,
    accessNotes: 'Scraped candidate — verify the nearest open access point, ramp, and parking before publishing.',
    adaFishing: 'unknown',
    adaParking: 'unknown',
    pavedRouteToWater: 'unknown',
    accessibleRestroom: 'unknown',
    parking: { available: 'unknown', adaStatus: 'unknown', surface: 'unknown' },
    permit: {
      required: true,
      kind: 'state_license',
      summary: 'A valid Oklahoma fishing license is generally required unless an exemption applies.',
      officialUrl: ODWC_AREAS,
    },
    sourceName: p.sourceName,
    sourceUrl: p.sourceUrl?.startsWith('https://') ? p.sourceUrl : ODWC_AREAS,
    verifiedAt: TODAY,
    verificationStatus: p.verificationStatus ?? 'needs_verification',
  };
}

/* -------------------------------------------------------------------- run */

const report = { overpass: 0, odwc: 0, ridb: 0, kept: 0, droppedDuplicates: 0 };
const seen = [];
const candidates = [];

if (!args.has('--skip-overpass')) {
  try {
    const pts = await scrapeOverpass();
    report.overpass = pts.length;
    for (const p of pts) { const a = toAccessPoint(p, seen); if (a) candidates.push(a); else report.droppedDuplicates += 1; }
  } catch (e) { console.warn(`Overpass skipped: ${e.message}`); }
}

if (!args.has('--skip-odwc')) {
  try {
    const pts = await scrapeOdwc();
    report.odwc = pts.length;
    for (const p of pts) { const a = toAccessPoint(p, seen); if (a) candidates.push(a); else report.droppedDuplicates += 1; }
  } catch (e) { console.warn(`ODWC skipped: ${e.message}`); }
}

if (!args.has('--skip-ridb') && process.env.RIDB_API_KEY) {
  try {
    const pts = await scrapeRidb();
    report.ridb = pts.length;
    for (const p of pts) { const a = toAccessPoint(p, seen); if (a) candidates.push(a); else report.droppedDuplicates += 1; }
  } catch (e) { console.warn(`RIDB skipped: ${e.message}`); }
}

report.kept = candidates.length;
await mkdir('data', { recursive: true });
await writeFile('data/oklahoma-access-scraped.json', JSON.stringify(candidates, null, 2));

console.log('\nOklahoma access scrape complete:');
console.log(`  OSM/Overpass candidates : ${report.overpass}`);
console.log(`  ODWC pages with coords  : ${report.odwc}`);
console.log(`  RIDB federal sites      : ${report.ridb}`);
console.log(`  Kept after 250m dedupe  : ${report.kept}`);
console.log(`  Dropped as duplicates   : ${report.droppedDuplicates}`);
console.log('Review queue written to data/oklahoma-access-scraped.json');
console.log('Next: hand-verify candidates, then promote into src/lib/publicAccess.ts.');
