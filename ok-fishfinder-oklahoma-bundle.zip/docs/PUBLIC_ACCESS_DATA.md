# Public Fishing Access Data

## Purpose

This registry stores source-traceable information about Oklahoma public fishing access points,
not just water bodies. One lake can have several ramps, piers, shorelines, and parking areas.

## Data sources (Oklahoma Fishfinder Pro)

Official and open-license sources only. **Do not scrape Fishbrain, AnglerAtlas, or any other
community platform** — their terms prohibit scraping, and community reports may never
overwrite official records. Use community apps, if at all, only as leads for manual
verification against an official source.

Automated collection lives in `scripts/scrape-oklahoma-access.mjs`
(run `npm run scrape:ok-access`):

1. **OpenStreetMap via Overpass API (ODbL)** — boat ramps, fishing nodes, access points with
   coordinates. Primary coordinate source; attribute "© OpenStreetMap contributors (ODbL)".
2. **Oklahoma Department of Wildlife Conservation** (wildlifedepartment.com) — where-to-fish
   region pages and department fishing-area pages; supplies access notes, permit rules, and
   verification URLs.
3. **Recreation.gov RIDB API** (optional; set `RIDB_API_KEY`) — federal recreation sites.

The script writes a review queue to `data/oklahoma-access-scraped.json`. Records enter
`src/lib/publicAccess.ts` only after human review; scraped candidates default to
`needs_verification` unless the source is an official agency page.

## Accessibility policy

- Mark ADA fishing or ADA parking as `confirmed` only when an official operator source explicitly
  describes that specific facility.
- Use `unknown` when details have not been verified.
- Never infer lake-wide accessibility from one accessible facility.

## Permit policy

Keep baseline state-license guidance separate from location-specific city permits, land-access
permits, day-use fees, check-in requirements, and special regulations.

## Required data fields

Every record must include:

- A stable unique ID.
- Facility/access-point coordinates.
- An official source URL.
- A verification date.
- A verification status.
- Explicit unknown values instead of guessed parking or accessibility details.

## Source precedence

1. Site operator or managing agency.
2. Oklahoma Department of Wildlife Conservation.
3. Federal land/water manager (USACE, NPS, Bureau of Reclamation, Recreation.gov).
4. OpenStreetMap (ODbL) for coordinates and facility type only.
5. Local municipality or county.
6. Community reports, clearly labeled and never used to overwrite official information.

## Refresh cadence

Run the scraper before each fishing season and whenever a managing agency publishes a closure,
construction update, or regulation update. Review the scraped queue before promoting records.

## Local validation

Run `validatePublicAccessData()` (src/lib/publicAccess.ts) in a dev check or unit test to ensure
records stay consistent.
